# Scenario Script Validation Log

> **HUMAN-EDITED ONLY.** Only the two reviewing ED physicians edit the decision rows
> below. Agents, scripts and tooling must never write, pre-fill, or alter a decision,
> initials, date, or hash in this file.

## How this log is used

- `make_paper_assets` treats a script as **validated only if two distinct reviewers
  recorded `validated` for the current content hash** (the YAML status stays
  `pending`; any other status such as `provisional` blocks validation)
  — i.e. the `script sha256` recorded in
  each reviewer's row must equal the sha256 of the script file as it exists at
  asset-generation time. Any edit to a script after review changes its hash and the
  script reverts to *not validated* until both reviewers re-review the new content.
- The `validation_status` field inside each YAML script stays `pending`; it is not
  edited after review, because changing it would change the content hash that the
  approvals and the selected verification runs are bound to. The two recorded
  approvals are authoritative; agents must not set the status or enter decisions.
- Copy the sha256 from the script's review page `review/<ID>.md` (regenerate the pages
  first with `backend/venv/bin/python experiments/scripts/make_review_md.py`), or
  compute it with `sha256sum experiments/scripts/<ID>.yaml`.
- Reviewers should record decisions independently before discussing disagreements.

## Field definitions

| Column | Allowed values / meaning |
| --- | --- |
| script sha256 | Full 64-hex sha256 of `experiments/scripts/<ID>.yaml` at the time of review |
| reviewer | Reviewer initials |
| date | Review date, `YYYY-MM-DD` |
| decision | `validated` \| `needs-change` \| `rejected` |
| plausibility | `ok` \| `issue` — scenario is clinically plausible for the stated profile |
| facts consistent | `ok` \| `issue` — patient_facts and expected_answers agree and suffice to answer every question |
| expected route | `ok` \| `issue` — chest / headache / abdomen route is correct |
| expected safety triggers | `ok` \| `issue` — expected/acceptable rule IDs, or the documented coverage gap, are correct |
| expected path | `ok` \| `issue` \| `n/a (pending)` — expected questionnaire path, once filled |
| comments | Free text; required for `needs-change` or `rejected` |

## Decisions

| script | script sha256 | reviewer | date | decision | plausibility | facts consistent | expected route | expected safety triggers | expected path | comments |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CP-01 |  |  |  |  |  |  |  |  |  |  |
| CP-01 |  |  |  |  |  |  |  |  |  |  |
| CP-02 |  |  |  |  |  |  |  |  |  |  |
| CP-02 |  |  |  |  |  |  |  |  |  |  |
| CP-03 |  |  |  |  |  |  |  |  |  |  |
| CP-03 |  |  |  |  |  |  |  |  |  |  |
| CP-04 |  |  |  |  |  |  |  |  |  |  |
| CP-04 |  |  |  |  |  |  |  |  |  |  |
| CP-05 |  |  |  |  |  |  |  |  |  |  |
| CP-05 |  |  |  |  |  |  |  |  |  |  |
| CP-06 |  |  |  |  |  |  |  |  |  |  |
| CP-06 |  |  |  |  |  |  |  |  |  |  |
| CP-07 |  |  |  |  |  |  |  |  |  |  |
| CP-07 |  |  |  |  |  |  |  |  |  |  |
| CP-08 |  |  |  |  |  |  |  |  |  |  |
| CP-08 |  |  |  |  |  |  |  |  |  |  |
| CP-09 |  |  |  |  |  |  |  |  |  |  |
| CP-09 |  |  |  |  |  |  |  |  |  |  |
| CP-10 |  |  |  |  |  |  |  |  |  |  |
| CP-10 |  |  |  |  |  |  |  |  |  |  |
| HA-01 |  |  |  |  |  |  |  |  |  |  |
| HA-01 |  |  |  |  |  |  |  |  |  |  |
| HA-02 |  |  |  |  |  |  |  |  |  |  |
| HA-02 |  |  |  |  |  |  |  |  |  |  |
| HA-03 |  |  |  |  |  |  |  |  |  |  |
| HA-03 |  |  |  |  |  |  |  |  |  |  |
| HA-04 |  |  |  |  |  |  |  |  |  |  |
| HA-04 |  |  |  |  |  |  |  |  |  |  |
| HA-05 |  |  |  |  |  |  |  |  |  |  |
| HA-05 |  |  |  |  |  |  |  |  |  |  |
| HA-06 |  |  |  |  |  |  |  |  |  |  |
| HA-06 |  |  |  |  |  |  |  |  |  |  |
| HA-07 |  |  |  |  |  |  |  |  |  |  |
| HA-07 |  |  |  |  |  |  |  |  |  |  |
| HA-08 |  |  |  |  |  |  |  |  |  |  |
| HA-08 |  |  |  |  |  |  |  |  |  |  |
| HA-09 |  |  |  |  |  |  |  |  |  |  |
| HA-09 |  |  |  |  |  |  |  |  |  |  |
| HA-10 |  |  |  |  |  |  |  |  |  |  |
| HA-10 |  |  |  |  |  |  |  |  |  |  |
| AP-01 |  |  |  |  |  |  |  |  |  |  |
| AP-01 |  |  |  |  |  |  |  |  |  |  |
| AP-02 |  |  |  |  |  |  |  |  |  |  |
| AP-02 |  |  |  |  |  |  |  |  |  |  |
| AP-03 |  |  |  |  |  |  |  |  |  |  |
| AP-03 |  |  |  |  |  |  |  |  |  |  |
| AP-04 |  |  |  |  |  |  |  |  |  |  |
| AP-04 |  |  |  |  |  |  |  |  |  |  |
| AP-05 |  |  |  |  |  |  |  |  |  |  |
| AP-05 |  |  |  |  |  |  |  |  |  |  |
| AP-06 |  |  |  |  |  |  |  |  |  |  |
| AP-06 |  |  |  |  |  |  |  |  |  |  |
| AP-07 |  |  |  |  |  |  |  |  |  |  |
| AP-07 |  |  |  |  |  |  |  |  |  |  |
| AP-08 |  |  |  |  |  |  |  |  |  |  |
| AP-08 |  |  |  |  |  |  |  |  |  |  |
| AP-09 |  |  |  |  |  |  |  |  |  |  |
| AP-09 |  |  |  |  |  |  |  |  |  |  |
| AP-10 |  |  |  |  |  |  |  |  |  |  |
| AP-10 |  |  |  |  |  |  |  |  |  |  |
