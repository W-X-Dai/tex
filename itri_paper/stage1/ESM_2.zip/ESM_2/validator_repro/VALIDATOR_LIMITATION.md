# Open-choice validation limitation

Recorded 2026-10-13. This is a software verification limitation, not clinical
validation. A successful FHIR transaction does not establish profile conformance.

HL7 validator **6.10.4** (Git `1b90fb13f77b`) raises an infrastructure exception
when an R4 `open-choice` answer contains `valueString` and a nested question has
an `enableWhen` comparison against `answerCoding`. The retained minimal example
contains only one synthetic question and answer. It uses no custom extensions,
TW Core profile, terminology server, patient identifier, or patient record.

## Reproduction

Run from the repository root with the already installed validator and cached R4
packages. Do not install or update packages as part of this reproduction.

```bash
cd experiments/validator_repro
sha256sum -c SHA256SUMS
cd ../..
java -jar /home/user/tools/hl7-validator/validator_cli-6.10.4.jar \
  experiments/validator_repro/QuestionnaireResponse.json \
  -version 4.0.1 \
  -ig experiments/validator_repro/defs \
  -tx n/a \
  -output /tmp/preconsult-validator-repro-out.json \
  > /tmp/preconsult-validator-repro.log 2>&1
```

The expected observed diagnostic is:

```text
Validation Infrastructure fail ... Expected answer and actual answer have incompatible types
org.hl7.fhir.validation.instance.utils.EnableWhenEvaluator.evaluateAnswer
```

Inspect the output and log, not only the process exit code. A validator exception
is failed verification; it must not be reported as zero errors or as a passed
resource. Report infrastructure exceptions separately from profile error counts
and retain the combined verification-failure count used by the experiment.

[The manifest](validator_repro/manifest.json) records exact input SHA-256 values,
validator JAR SHA-256, original command, runtime, and original log hash. The
committed input files are byte-identical copies of the original synthetic
reproduction under `/tmp/codex-fhir-validator/`; the originals were preserved.
Re-running the exact command above against these repository fixtures reproduced
the same exception with exit status **1**. Its complete
[observed log](validator_repro/observed.log) and SHA-256 are retained in the manifest.

## Relation to the system

The original E1 run `results/e1_interop/20261013T062941Z` recorded 11 written
resources. Its three QuestionnaireResponses encountered this exception; the
other eight resources had no reported structural errors. The originating field
was an open-choice blood-type answer containing the synthetic EHR placeholder
`FHIR 未提供`, preserved as `valueString`. Its `.other` detail compares the parent
answer against coding `other`. Replacing the placeholder with coding `other`
would invent a selection and change the answer's meaning, so no such workaround
was applied. The minimal example uses the English synthetic string
`Not provided by EHR` to isolate the same comparison without application data.

A separate current-code fixture containing Questionnaire, QuestionnaireResponse,
Observation, Composition, and Provenance completed offline validation with
**0 errors and 5 warnings**. These warnings were one Composition `dom-6` narrative
warning and four unresolved Provenance participant CodeSystem version warnings.
The fixture used supported structured answers. It does not overturn the failures
for actual raw-prefill responses, and `-tx n/a` does not establish terminology
conformance. Original outputs are in `/tmp/codex-backend-validation/`.

There is also a separate application limitation: runtime conditions can substring
match arbitrary EHR text while FHIR `enableWhen` compares codings. Structured
writeback now checks the enabled paths and returns sanitized HTTP 503 before
the transaction if they disagree. The local consultation remains stored. This
guard prevents silently dropping an answered follow-up; it does not fix the
validator exception described above. Legacy Composition-only writeback is
unchanged and structured writeback remains opt-in.

An independently reviewed validator correction or a standards-preserving encoding
change requires a new immutable validation run. Preserve these failed runs and
the original reproduction when comparing later outcomes. No conclusion about
diagnostic accuracy, clinical safety, or production readiness follows from either
the successful fixture or the exception.

## Fix round 2026-10-13

The independent review recorded in `docs/paper/codex_fix_spec_2026-10-13.md`
section 1.1 also reproduced the incompatible-types exception with **7.0.1**.
That is reviewer-supplied evidence, not a new execution in this fix round. The
paper and all new checks remain pinned to **6.10.4**. The original minimal
reproduction and all failed run directories are preserved unchanged.

The QR builder now omits the EHR no-data sentinel `FHIR 未提供` instead of
asserting it as an answer. Read-only inspection of both frontend FHIR adapters
found this same prefill sentinel; other `未提供`/`未記錄` strings are presentation
labels, and clinical uncertainty answers are not filtered. Runtime prefill and
question-skipping behavior is unchanged. In particular, absent blood type still
causes the runtime to skip that question; this round does not repair that behavior.
Non-grammar open-choice text is encoded using the existing `other` coding and
`<linkId>.other` text child. All original text and answer-source markers remain.
Decoding uses the existing `其他：` grammar prefix without losing the source text.

Pinned-validator evidence is retained in
`verification/fix-20261013-20261013T132857Z/` (command, hashes, fixtures, log,
OperationOutcomes and summary). Both corrected QR fixtures, with and without an
answered `chronic_detail`, have **0 errors and 0 warnings**, with no infrastructure
exception. The five actual builder resources have zero errors overall. This
fixture check does not substitute for the new E1 cohort run.

The same check investigated the four Provenance participant warnings. The backend
uses the correct CodeSystem URL. TW Core 1.0.0's bundled
`ValueSet-provenance-participant-type-hl7-tw.json` explicitly binds CodeSystem
version `4.0.1`, while the cached CodeSystem has versions `0.1.0`, `1.1.0` and
`2.0.0`. An additional, separately identified diagnostic Provenance copy with
explicit coding version `1.1.0` produced **4 errors and 8 warnings**. It is not a
system-output sample and is not included in E1. Neither changing this coding
version nor disabling checks is an acceptable warning workaround. The unchanged
actual Provenance has zero errors and four warnings; Composition has one narrative
warning. Offline `-tx n/a` still does not demonstrate full terminology resolution.

The previous unconditional branching guard is replaced by an answered-item
check. Coded `other` makes the HIS value `高血壓; 癌症` and its saved follow-up
representable. A remaining enabled, answered branch that FHIR would discard
fails closed with sanitized HTTP **422**, not a retryable 503; unfilled branches
do not cause rejection. Questionnaire canonical versions captured during the
interview are checked before write-back. Mismatches also return 422. Legacy
records without a captured canonical retain current resolution and carry the
`legacy-writeback-resolution` meta tag.
