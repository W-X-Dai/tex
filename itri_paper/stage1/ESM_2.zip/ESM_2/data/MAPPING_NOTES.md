# Synthea v4.0.0 → TW Core 1.0.0 mapping notes

Source of every number below: `conversion_stats.json` (converter counters),
`terminology_coverage.json`, `input_validation_summary*.json` and
`hapi_load_report.json`, all produced by the scripts in this directory from the
fixed-seed run recorded in `generation_manifest.json`. The data is entirely
synthetic.

## 1. Cohort

- Synthea v4.0.0 (commit `0185c09e`), seed 20261013, clinician seed 20261013,
  reference and end date 2026-10-01, `-a 20-90`, Massachusetts demographics,
  living patients only, 5 years of exported history
  (`exporter.years_of_history = 5`; Synthea still exports older encounters that
  established a still-active condition).
- 1,000 patients generated; 1,000 kept (age 20–89 on 2026-10-01; 0 removed by
  the converter's `age >= 20` guard).
- Export was restricted at generation time
  (`exporter.fhir.included_resources`) to Patient, Encounter, Condition,
  Observation, MedicationRequest, Medication and AllergyIntolerance. Claim,
  ExplanationOfBenefit, Provenance, DiagnosticReport, DocumentReference,
  CarePlan, CareTeam, Procedure, Immunization, ImagingStudy, Device and
  SupplyDelivery were therefore never produced and are not counted as drops.
  Practitioner/Organization/Location bundles were not exported either.

## 2. Resource-level mapping

| Synthea resource | Input | Converted | Dropped | TW Core profile |
| --- | ---: | ---: | ---: | --- |
| Patient | 1,000 | 1,000 | 0 | Patient-twcore |
| Encounter | 37,401 | 37,401 | 0 | Encounter-twcore |
| Condition | 28,464 | 28,464 | 0 | Condition-twcore |
| Observation | 329,134 | 329,134 | 0 | 15 Observation profiles (§4) |
| MedicationRequest | 33,250 | 33,250 | 0 | MedicationRequest-twcore |
| AllergyIntolerance | 768 | 768 | 0 | AllergyIntolerance-twcore |
| Medication | 0 | — | — | not emitted; any `medicationReference` is inlined (0 occurrences in this cohort) |
| **Total** | **430,017** | **430,017** | **0** | |

No MedicationStatement is produced: Synthea models prescribing only, and
deriving patient-reported medication statements would invent information. Active
medications are MedicationRequest with `status = active` (see `patient_index.py`).

Every converted resource has `meta.profile` (one TW Core profile) and
`meta.tag` `https://medical-consultation.local/fhir/paper-experiments|synthea-twcore-v1`.
Ids are `syn-<Synthea UUID>`; each patient is one `transaction` Bundle
(`Bundle-twcore`) of `PUT <Type>/<id>` entries with relative references.

## 3. Element-level decisions (counts = resources affected)

### Patient (1,000)

| Decision | Count |
| --- | ---: |
| Synthea US name(s) replaced by one synthetic zh-TW `official` name (`text`, `family`, `given`) from fixed lists of 30 surnames and 20 + 20 given-name characters | 1,000 |
| Additional Synthea names (maiden) removed | 381 |
| US address (incl. geolocation extension) replaced by a synthetic TW address: real county/district + postal code from the 5-concept `postal-code3-tw` CodeSystem shipped in the IG, a **fictional** road name (模擬路/範例街/測試大道/合成路/虛擬街), `tw-section`/`tw-lane`/`tw-number` extensions | 1,000 |
| Address convention follows the IG example `Patient/pat-example`: `city` = township/district, `district` = county/city | 1,000 |
| US identifiers removed: Synthea id, MRN, SSN, driver's licence (1,000 each), passport (999) | 4,999 |
| Synthetic MRN added in the `medicalRecord` slice (type v2-0203 `MR`, system `https://medical-consultation.local/fhir/sid/synthetic-mrn`, value `SYN` + 8 digits from SHA-256(seed, UUID); uniqueness checked) | 1,000 |
| **No national ID** (`idCardNumber` slice, `http://www.moi.gov.tw`) generated: a checksum-valid ID could coincide with a real person; the slice is 0..1 | 1,000 |
| `telecom` removed (US 555 numbers; no synthetic TW phone generated) | 1,000 |
| Extensions removed: mothersMaidenName, birthPlace, Synthea DALY, Synthea QALY | 1,000 each |
| Synthea narrative (`text`, contains US name and seed) removed | 1,000 |
| `communication.language` set to `zh-TW` (Synthea: en-US/es etc.) | 1,000 |
| Kept unchanged: `gender`, `birthDate`, `maritalStatus` (v3-MaritalStatus), `multipleBirth[x]` | 1,000 |

### Encounter (37,401)

| Decision | Count |
| --- | ---: |
| `participant` removed (conditional reference to a non-exported Practitioner) | 37,401 |
| `serviceProvider` removed (conditional reference to a non-exported Organization) | 37,401 |
| `serviceType` not populated: Synthea has no source for the NHI department slices (`medical-consultation-department-nhi-tw`, `medical-treatment-department-nhi-tw`, `medical-department-sct-tw`) | 37,401 |
| Kept: `status`, `class` (v3-ActCode AMB 34,312 / EMER 1,411 / IMP 849 / HH 683 / VR 146), `type` (SNOMED CT, 53 codes), `period`, `reasonCode`, `hospitalization.dischargeDisposition` (NUBC) | — |

### Condition (28,464)

| Decision | Count |
| --- | ---: |
| `category` added = `encounter-diagnosis` (absent in Synthea; TW Core requires 1..1) | 28,464 |
| `code`: SNOMED CT kept (244 distinct concepts, `sct` slice); **no ICD-10-CM TW coding** | 28,464 |
| Kept: `clinicalStatus` (active 11,965 / resolved 16,499), `verificationStatus`, `encounter`, `onsetDateTime`, `abatementDateTime`, `recordedDate` | — |

ICD-10-CM (TW 2014/2021/2023) could not be mapped: no SNOMED CT → ICD-10-CM map
is available offline, and the IG package ships the TW ICD-10-CM CodeSystems as
example subsets (5, 18 and 11 concepts) declared `content = complete`, so any
real code outside those subsets would fail validation regardless.

SNOMED CT semantic tags of Condition.code: finding 14,208; disorder 8,804;
situation 5,253; morphologic abnormality 95; person 57; no tag in display 47
(disorders such as "Gout"). Three concepts lie outside the `condition-code-sct-tw`
hierarchies (clinical finding / situation / event): 384709000 *Sprain
(morphologic abnormality)* (69), 48333001 *Burn injury (morphologic abnormality)*
(26) and 446654005 *Refugee (person)* (57). They are kept unchanged (no
clinical re-coding without review); see §5 for how the validator treats them.
Synthea's Condition list also contains social-determinant findings (e.g.
employment, education, stress); they are kept, and `patient_index.json` exposes the
display so scenario matching can ignore them.

### MedicationRequest (33,250)

| Decision | Count |
| --- | ---: |
| `medicationCodeableConcept`: RxNorm only (223 distinct codes; `rxnorm-medication-us-core` slice). No TW FDA licence, NHI drug or ATC coding: no offline RxNorm → NHI/ATC crosswalk exists in the repository | 33,250 |
| `requester` removed (non-exported Practitioner) | 33,250 |
| Kept: `status` (active 3,716 / completed 29,534), `intent`, `subject`, `encounter`, `authoredOn`, `reasonReference` (to converted Conditions), `reasonCode`, `dosageInstruction` | — |

### AllergyIntolerance (768)

All elements kept; `code` is SNOMED CT (677; 16 codes) or RxNorm (91; 6 codes);
reaction manifestations SNOMED CT. No element removed.

## 4. Observation routing (329,134)

Routing is by Synthea category and primary LOINC code (`twcore_mapping/observation.py`).

| TW Core profile | Rule | Count |
| --- | --- | ---: |
| Observation-laboratoryResult-twcore | category `laboratory` | 229,478 |
| Observation-screening-assessment-twcore | category `survey` | 28,110 |
| Observation-simple-twcore | category `vital-signs` with a code outside `vital-signs-tw` (below) | 16,854 |
| Observation-bloodPressure-twcore | 85354-9 | 7,662 |
| Observation-body-weight-twcore | 29463-7 | 7,248 |
| Observation-heart-rate-twcore | 8867-4 | 7,185 |
| Observation-respiratory-rate-twcore | 9279-1 | 7,185 |
| Observation-bmi-twcore | 39156-5 | 7,170 |
| Observation-body-height-twcore | 8302-2 | 7,170 |
| Observation-smoking-status-twcore | social-history 72166-2 | 7,170 |
| Observation-clinical-result-twcore | category exam / imaging / procedure / therapy | 2,836 |
| Observation-body-temperature-twcore | 8310-5 | 389 |
| Observation-pulse-oximetry-twcore | 2708-6 **and** 59408-5 both present | 251 |
| Observation-pregnancy-status-twcore | social-history 82810-3 | 228 |
| Observation-pediatric-bmi-age-twcore | 59576-9 (BMI percentile recorded before age 20 within the history window) | 181 |
| Observation-sexual-orientation-twcore | social-history 76690-7 | 13 |
| Observation-vitalSigns-twcore | other `vital-signs-tw` codes (8478-0 mean BP) | 4 |

Observation-simple-twcore fallback (category kept as `vital-signs`; codes are not
in the `vital-signs-tw` ValueSet): 72514-3 pain severity 11,847; 74006-8
dialysis weight difference 4,041; 79892-6 / 79893-4 intraocular pressure 471 each;
71425-3 NT-proBNP 19 (a laboratory test that Synthea labels vital-signs); 86923-0
KCCQ-12 3; 70006-2 1; 91148-7 PEG 1.

Element-level Observation decisions:

| Decision | Count |
| --- | ---: |
| Coding with a SNOMED CT concept id labelled `system = http://loinc.org` removed (Synthea defect, e.g. 41633001 *Intraocular pressure* on 79892-6/79893-4); detected as an all-digit "LOINC" code, which cannot exist because LOINC codes carry a check digit after a hyphen | 942 |
| Secondary coding 8331-1 *Oral temperature* removed because Observation-body-temperature-twcore restricts `code.coding` to 1..1 (body site information lost) | 389 |
| Kept: `status`, `category`, `code`, `subject`, `encounter`, `effectiveDateTime`, `issued`, `value[x]` (Quantity/CodeableConcept/String), `component` | — |
| No `performer` (Synthea provides none; validator best-practice warning) | 329,134 |

LOINC codes are kept as-is (204 distinct in Observation.code). No NHI
medical-service-payment codes (`laboratory-category-tw`) are added; the
laboratory code binding is extensible and LOINC is part of `laboratory-code-tw`.

## 5. Validation

The original 1,000-bundle validation completed: 430,017 resources, 46 errors,
1,058,848 warnings. All errors concerned the obsolete display for LOINC 57905-2;
no code or clinical value was changed. The converter records each of the 46 display
corrections, with provenance from the terminology-enabled validator response.
Original inputs and outcomes are retained.

`input_validation_summary_v2.json` verifies **all 1,000 corrected bundles**:
430,017 resources, **0 errors**, 1,058,802 warnings. `summarise_revision.py` checks
both dataset fingerprints, exact one-outcome-per-file coverage, and byte identity
for the 954 unchanged bundles; it replaces outcomes only for the 46 independently
revalidated bundles. The corrected 50-bundle terminology sample has 13,877
resources, **0 errors**, 24,240 warnings. The initial sample (2 display errors)
remains in `input_validation_summary_tx.json`.

`-tx n/a` disables remote terminology access but cached terminology responses still
apply. Therefore offline results are not proof that no terminology checks ran.
Neither structural conformance nor the sampled terminology check establishes
clinical validity or complete Taiwan-specific coding.

The separately authored five-patient supplement has 33 resources, 0 errors,
49 warnings. The 30-patient scenario cohort has 18,008 resources, 0 errors,
45,290 warnings. Supplement conditions use a visibly synthetic local code system
with the exact pending scenario labels; no standard clinical terminology mapping
or epidemiological realism is claimed.

## 6. HAPI load

The 30-scenario cohort was validated before loading; HAPI accepted all 30
transactions and 18,008 entry responses. An additional 200 unchanged inputs were
selected by their individual zero-error OperationOutcomes and loaded with zero
failed transactions. Full-cohort load evidence is written separately to
`hapi_load_report_v2.json`; use its recorded counts and timestamps, not intermediate
server totals. Existing tagged resources were not deleted.

## 7. Limitations (for the paper)

1. **US clinical epidemiology, Taiwanese surface.** Disease prevalence, care
   pathways, laboratory panels and prescribing follow Synthea's US modules; only
   demographics (names, addresses, language, identifiers) are localised.
2. **No Taiwanese code systems in clinical content.** Conditions carry SNOMED CT
   only in the base cohort (no ICD-10-CM TW); supplements use explicit local
   synthetic codes. Medications RxNorm only (no TW FDA/NHI/ATC), labs LOINC
   only (no NHI payment codes), and Encounter has no NHI department. These slices
   are optional in TW Core, so the data conforms, but systems that require TW
   national codes will not find them.
3. **No practitioners or organisations.** Performer/requester/participant
   references were removed (37,401 encounters; 33,250 prescriptions), so
   provenance of clinical acts is absent.
4. **Narrative.** No resource carries `text`; resources may receive the
   best-practice warning dom-6.
5. **Terminology validation is partial.** The full-cohort validation ran with
   `-tx n/a` (remote access disabled; cached responses can still apply). A
   separate 50-bundle sample used tx.fhir.org; this is not full-cohort remote
   terminology coverage.
6. **Synthea artefacts retained.** Social-determinant "conditions", Synthea's
   vital-signs category on non-vital codes, and three SNOMED concepts outside the
   TW Core condition hierarchies are kept rather than clinically re-coded.
7. **Restricted resource set.** Procedures, immunizations, care plans, diagnostic
   reports and documents were not exported, so they are unavailable to the
   chatbot and to evaluation.
