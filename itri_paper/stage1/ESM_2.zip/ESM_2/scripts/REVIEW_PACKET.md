# Scenario Script Review Packet

Generated 2026-10-13 by `experiments/scripts/make_review_packet.py`. Do not edit by hand; regenerate after any script change.

All scripts are SYNTHETIC, author-drafted system-verification scenarios. They are not derived from real patients and are not a clinical accuracy benchmark. Expected routes and safety triggers are software expectations against the current rule set (`backend/amie/rules/safety_rules.json`) and are NOT clinically validated until both reviewers record `validated` in `VALIDATION_LOG.md` for the sha256 shown on each page.

| Script | Route | Red flag | Expected triggers | Coverage gap | sha256 (first 12) |
| --- | --- | --- | --- | --- | --- |
| AP-01 | abdomen | no | — | — | `a81d20fb5898` |
| AP-02 | abdomen | no | — | — | `b99f9f46352e` |
| AP-03 | abdomen | no | — | — | `2bd0a861dee2` |
| AP-04 | abdomen | no | — | — | `aad772ac2183` |
| AP-05 | abdomen | no | — | — | `e7699a337c80` |
| AP-06 | abdomen | no | — | — | `bbbfaa1ec133` |
| AP-07 | abdomen | yes | semantic_altered_consciousness, semantic_abdominal_syncope | — | `c9b10e6da2fc` |
| AP-08 | abdomen | yes | pregnancy_bleeding | — | `f0464a99e9f9` |
| AP-09 | abdomen | yes | peritonism | — | `029dad1424f8` |
| AP-10 | abdomen | yes | — | yes | `b182526cb7b9` |
| CP-01 | chest | no | — | — | `681423f38f65` |
| CP-02 | chest | no | — | — | `b0e3eed3dc0d` |
| CP-03 | chest | no | — | — | `354ff272e45c` |
| CP-04 | chest | no | — | — | `5609b8e2dd53` |
| CP-05 | chest | no | — | — | `1acd0a6a8641` |
| CP-06 | chest | no | — | — | `bc53832a7289` |
| CP-07 | chest | yes | chest_diaphoresis | — | `95fa050073ac` |
| CP-08 | chest | yes | tearing_chest_pain | — | `75d1c793ab15` |
| CP-09 | chest | yes | — | yes | `f9747f81d5a8` |
| CP-10 | chest | yes | chest_syncope | — | `faaee81c81a1` |
| HA-01 | headache | no | — | — | `ded73b7103f6` |
| HA-02 | headache | no | — | — | `73fdf57f1dbd` |
| HA-03 | headache | no | — | — | `1212153bcf54` |
| HA-04 | headache | no | — | — | `879453a50298` |
| HA-05 | headache | no | — | — | `5b4e27f291be` |
| HA-06 | headache | no | — | — | `79f8396df783` |
| HA-07 | headache | yes | thunderclap_headache | — | `d48658dc6d2f` |
| HA-08 | headache | yes | semantic_meningism | — | `6b466d617767` |
| HA-09 | headache | yes | focal_neurologic_deficit | — | `12f40fc48638` |
| HA-10 | headache | yes | altered_consciousness | — | `241880a1040d` |

<div style="page-break-after: always;"></div>

## AP-01

- Script file: `experiments/scripts/AP-01.yaml`
- sha256 at packet generation: `a81d20fb589880c8e1def3f93305af31b07b80771c97558ced069c0dee2f4f4c`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: no
- Patient profile: male, age 45–55; required conditions: none; excluded: none
- Source: authored-for-this-study (seeded from feasibility/abdomen-01)
- Validation status (script field): `pending`
- Author notes: Dyspepsia-type presentation. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 胃痛好幾天了，空腹的時候比較痛，有點想吐

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一週前，慢慢出現。 |
| 性質 character | 悶悶的痛，肚子餓時更痛。 |
| 部位 location | 左上腹、心窩附近。 |
| 嚴重度 severity | 中等，會影響工作。 |
| 加重因子 aggravating | 空腹、肚子餓的時候。 |
| 緩解因子 relieving | 吃點東西會好一點。 |
| 伴隨症狀 associated | 有點想吐。 |
| 否認症狀 negatives | 沒有吐血、沒有黑便或血便、沒有發燒、沒有腹瀉。 |
| 過去病史 past history | 沒有慢性病，沒有腹部疾病史。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 最近三餐不定時，家人沒有相同症狀。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 胃痛好幾天了，空腹的時候比較痛，有點想吐 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 1週前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 逐漸出現 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 中等，已影響活動 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 飢餓時會加劇疼痛 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 左上腹 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 噁心 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d540260-5154-cb49-e41e-ade28f1f70b0
- Synthetic cohort: scenario-v2; age: 47
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-02

- Script file: `experiments/scripts/AP-02.yaml`
- sha256 at packet generation: `b99f9f46352ef2a539a15baa0524489b5efbf677f828043164949d67d932dd6b`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: no
- Patient profile: female, age 22–32; required conditions: none; excluded: appendectomy
- Source: authored-for-this-study (seeded from feasibility/abdomen-02)
- Validation status (script field): `pending`
- Author notes: Migratory periumbilical-to-RLQ pattern (appendicitis-like). Author-labelled non-red-flag at the chief-complaint turn because no current rule targets it (seed label); reviewers should confirm.

### Opening statement (verbatim chief complaint)

> 肚子痛從肚臍周圍開始，現在移到右下腹，有點發燒

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 昨天開始，慢慢出現。 |
| 性質 character | 一開始在肚臍周圍悶痛，後來移到右下腹。 |
| 部位 location | 右下腹。 |
| 嚴重度 severity | 中等，已經影響走路。 |
| 加重因子 aggravating | 走路、咳嗽時比較痛。 |
| 緩解因子 relieving | 躺著不動比較好。 |
| 伴隨症狀 associated | 有點發燒發冷、想吐。 |
| 否認症狀 negatives | 沒有腹瀉、沒有陰道出血、月經正常沒有過期、沒有暈倒。 |
| 過去病史 past history | 沒有慢性病，沒有腹部疾病史。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | O型。 |
| 其他 other | 家人沒有相同症狀。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 肚子痛從肚臍周圍開始，現在移到右下腹，有點發燒 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | O型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 1天前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 逐漸出現 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 中等，已影響活動 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 由肚臍周圍痛轉移到右下腹 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 右下腹 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 發燒發冷、噁心 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d4e2372-9634-16e9-ce88-89e062563bb4
- Synthetic cohort: scenario-v2; age: 22
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-03

- Script file: `experiments/scripts/AP-03.yaml`
- sha256 at packet generation: `2bd0a861dee22563585e7cff23671577820157712734b0b1314087c630a4e509`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: no
- Patient profile: female, age 55–65; required conditions: cholelithiasis, hyperlipidemia; excluded: none
- Source: authored-for-this-study (seeded from feasibility/abdomen-03)
- Validation status (script field): `pending`
- Author notes: Biliary-colic-type presentation. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 吃完油膩的東西右上腹痛，會痛到右肩

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 昨天晚餐吃炸物後開始。 |
| 性質 character | 一陣一陣的痛。 |
| 部位 location | 右上腹，會痛到右肩。 |
| 嚴重度 severity | 中等，已影響活動。 |
| 加重因子 aggravating | 吃油膩食物後。 |
| 緩解因子 relieving | 不吃東西、休息會好一點。 |
| 伴隨症狀 associated | 想吐。 |
| 否認症狀 negatives | 沒有發燒、沒有黃疸、沒有嘔吐、沒有暈倒。 |
| 過去病史 past history | 有膽結石和高血脂。過去沒有開過刀。 |
| 用藥 medications | Rosuvastatin 10 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 家人沒有相同症狀。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 吃完油膩的東西右上腹痛，會痛到右肩 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 高血脂、其他：膽結石 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 膽結石 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Rosuvastatin 10 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 1天前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 逐漸出現 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 中等，已影響活動 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 陣痛 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 右上腹 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 噁心 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 肝膽結石 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d5fc039-c796-3409-9cea-7d52ded81b36
- Synthetic cohort: scenario-v2; age: 57
- Active conditions: cholelithiasis; hyperlipidemia
- Active medications: Rosuvastatin 10 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 高血脂、其他：膽結石 | cholelithiasis、hyperlipidemia | text_difference_requires_review |
| current_meds | 其他：Rosuvastatin 10 mg 每日一次 | Rosuvastatin 10 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-04

- Script file: `experiments/scripts/AP-04.yaml`
- sha256 at packet generation: `aad772ac2183c9a2383fff961ca682fe9d0ff6d66ce1e8696dcfce13facedd7c`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: no
- Patient profile: male, age 20–30; required conditions: none; excluded: none
- Source: authored-for-this-study (seeded from feasibility/abdomen-04)
- Validation status (script field): `pending`
- Author notes: Gastroenteritis-type presentation with sick contacts. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 昨天吃路邊攤後一直腹痛拉肚子，同行朋友也一樣

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 昨天吃完路邊攤後幾小時開始。 |
| 性質 character | 一陣一陣的絞痛。 |
| 部位 location | 整個肚子。 |
| 嚴重度 severity | 中等，已影響活動。 |
| 加重因子 aggravating | 吃東西後比較想拉。 |
| 緩解因子 relieving | 拉完肚子後會好一點。 |
| 伴隨症狀 associated | 拉肚子、想吐。 |
| 否認症狀 negatives | 沒有血便、沒有發燒、沒有暈倒。 |
| 過去病史 past history | 沒有慢性病。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | A型。 |
| 其他 other | 一起吃飯的朋友也有同樣症狀。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 昨天吃路邊攤後一直腹痛拉肚子，同行朋友也一樣 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | A型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 1天前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 逐漸出現 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 中等，已影響活動 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 陣痛 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 全腹痛 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 腹瀉、噁心 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 是 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d59e14d-0c75-7fa9-cbd8-afbea1892918
- Synthetic cohort: scenario-v2; age: 23
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-05

- Script file: `experiments/scripts/AP-05.yaml`
- sha256 at packet generation: `e7699a337c80bb2b7fc1f5dcf3280fffe6eac29bf6a9ac01480a324a88617296`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: no
- Patient profile: male, age 60–70; required conditions: chronic kidney disease; excluded: none
- Source: authored-for-this-study (seeded from feasibility/abdomen-05)
- Validation status (script field): `pending`
- Author notes: Renal-colic-type presentation. Non-red-flag control. Seed opening had no routing keyword; rephrased to contain 肚子絞痛.

### Opening statement (verbatim chief complaint)

> 左邊腰痛連到肚子，一陣一陣的肚子絞痛，小便有點紅

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一小時前突然開始。 |
| 性質 character | 一陣一陣的絞痛。 |
| 部位 location | 左側腰部，延伸到肚子。 |
| 嚴重度 severity | 很痛，難以忍受。 |
| 加重因子 aggravating | 沒有特別姿勢會改變。 |
| 緩解因子 relieving | 沒有找到能緩解的方式。 |
| 伴隨症狀 associated | 小便有點紅、想吐。 |
| 否認症狀 negatives | 沒有發燒、沒有暈倒、沒有冒冷汗。 |
| 過去病史 past history | 有慢性腎臟病，以前有腎結石。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 家人沒有相同症狀。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 左邊腰痛連到肚子，一陣一陣的肚子絞痛，小便有點紅 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 慢性腎病 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 1小時前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 突然發作 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 劇烈，難以忍受 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 陣痛 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 左側腰痛 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 血尿、噁心 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 腎結石 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d3c86ad-64d1-f9c8-316b-534f3443dd63
- Synthetic cohort: scenario-v2; age: 61
- Active conditions: chronic kidney disease
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 慢性腎病 | chronic kidney disease | text_difference_requires_review |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-06

- Script file: `experiments/scripts/AP-06.yaml`
- sha256 at packet generation: `bbbfaa1ec133855b88d4ce1653fc2227b951361c6367718dff39de7aab3f5068`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: no
- Patient profile: female, age 70–80; required conditions: none; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: New script. Constipation-type lower abdominal discomfort. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 已經五天大不出來，下腹痛脹脹的

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約五天前開始，慢慢加重。 |
| 性質 character | 脹脹的悶痛。 |
| 部位 location | 肚臍以下的下腹部。 |
| 嚴重度 severity | 輕微，仍可正常活動。 |
| 加重因子 aggravating | 吃完東西後比較脹。 |
| 緩解因子 relieving | 有放屁會舒服一點。 |
| 伴隨症狀 associated | 便秘，五天沒有排便。 |
| 否認症狀 negatives | 沒有嘔吐、沒有發燒、沒有血便、沒有暈倒、還可以放屁。 |
| 過去病史 past history | 沒有慢性病。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 最近水喝得比較少。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 已經五天大不出來，下腹痛脹脹的 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 5天前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 逐漸出現 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 輕微，仍可正常活動 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 鈍痛 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 肚臍以下腹痛 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 便秘 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d36a7bf-a9b1-4568-c500-51b6dcad385b
- Synthetic cohort: scenario-v2; age: 78
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-07

- Script file: `experiments/scripts/AP-07.yaml`
- sha256 at packet generation: `c9b10e6da2fcaab752c388ac6dc9e2bd62dce334d5d0d3b7f8c86c9a9f1a045e`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: yes
- Patient profile: male, age 65–80; required conditions: hypertension; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red flag: ruptured-AAA-like (elderly smoker, abdominal pain to back + syncope). Natural word 昏倒 is NOT a raw term (raw abdomen terms are 腹痛昏厥/肚子痛暈倒; universal terms do not include 昏倒), so detection depends on LLM extraction of finding 'syncope'. structured_rules order puts semantic_altered_consciousness (any_findings altered_consciousness|syncope) before semantic_abdominal_syncope; both should be recorded. Lint marks requires_llm.

### Opening statement (verbatim chief complaint)

> 肚子痛到背後，剛剛上廁所的時候昏倒了一下

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一小時前突然開始。 |
| 性質 character | 持續的痛，從肚子痛到背後。 |
| 部位 location | 肚臍附近，延伸到背後。 |
| 嚴重度 severity | 很痛，難以忍受。 |
| 加重因子 aggravating | 一直都很痛。 |
| 緩解因子 relieving | 沒有任何方法能緩解。 |
| 伴隨症狀 associated | 上廁所時昏倒一次、冒冷汗。 |
| 否認症狀 negatives | 沒有發燒、沒有腹瀉、沒有吐血。 |
| 過去病史 past history | 有高血壓；不知道自己有沒有動脈瘤。過去沒有開過刀。 |
| 用藥 medications | Amlodipine 5 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 目前每天抽半包菸，抽了四十年。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 家人陪同前來。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 肚子痛到背後，剛剛上廁所的時候昏倒了一下 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 有，目前仍在抽 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Amlodipine 5 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 1小時前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 突然發作 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 劇烈，難以忍受 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 持續痛、由前痛到背後 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 其他：肚臍附近痛到背後 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 冒冷汗、昏厥或暈倒 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `semantic_altered_consciousness` — Structured (semantic) rule — requires LLM extraction: 「意識狀態異常」. Conditions: `{"any_findings": ["altered_consciousness", "syncope"]}`. Finding definitions: altered_consciousness = 意識改變、反應異常或無法正常喚醒。; syncope = 短暫失去意識或昏倒。
- `semantic_abdominal_syncope` — Structured (semantic) rule — requires LLM extraction: 「腹痛合併昏厥」. Conditions: `{"primary_in": ["abdomen"], "any_findings": ["syncope"]}`. Finding definitions: syncope = 短暫失去意識或昏倒。

Acceptable alternatives:

- `altered_consciousness` — Raw phrase rule, universal (all routes): 「意識狀態異常」. Fires when the chief-complaint text contains any of: 失去意識、昏迷、叫不醒 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).
- `abdominal_syncope` — Raw phrase rule, route `abdomen`: 「腹痛合併昏厥」. Fires when the chief-complaint text contains any of: 腹痛昏厥、肚子痛暈倒 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d484485-db13-6289-62d8-73716a173da4
- Synthetic cohort: scenario-v2; age: 73
- Active conditions: hypertension
- Active medications: Amlodipine 5 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Smokes tobacco daily (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：高血壓 | hypertension | text_difference_requires_review |
| current_meds | 其他：Amlodipine 5 mg 每日一次 | Amlodipine 5 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 有，目前仍在抽 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-08

- Script file: `experiments/scripts/AP-08.yaml`
- sha256 at packet generation: `f0464a99e9f9e84f1579bd18a4891332b018421847ec93c1a39e77ce83f6492d`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: yes
- Patient profile: female, age 20–35; required conditions: none; excluded: hysterectomy
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red flag: ectopic-pregnancy-like (reproductive-age woman, missed period, lower abdominal pain, vaginal bleeding). Opening uses raw term 月經過期又出血 (pregnancy_bleeding). A more natural phrasing (e.g. 月經晚了兩週，今天有出血) would match no raw term and the semantic rule also requires FHIR/prefill risk pregnancy_possible, i.e. it would likely be missed (see report).

### Opening statement (verbatim chief complaint)

> 我月經過期又出血，下腹痛得很厲害，站起來會頭暈

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約三小時前突然開始。 |
| 性質 character | 持續的痛。 |
| 部位 location | 肚臍以下、偏左下腹。 |
| 嚴重度 severity | 很痛，難以忍受。 |
| 加重因子 aggravating | 走路、站起來時更痛。 |
| 緩解因子 relieving | 躺著稍微好一點。 |
| 伴隨症狀 associated | 月經晚了兩週，今天有陰道出血，站起來會頭暈。 |
| 否認症狀 negatives | 沒有發燒、沒有腹瀉、沒有暈倒。 |
| 過去病史 past history | 沒有慢性病，沒有腹部疾病史。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 還沒有驗孕。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 我月經過期又出血，下腹痛得很厲害，站起來會頭暈 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 3小時前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 突然發作 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 劇烈，難以忍受 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 持續痛 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 左下腹、肚臍以下腹痛 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 月經過期、陰道出血、其他：站起來會頭暈 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `pregnancy_bleeding` — Raw phrase rule, route `abdomen`: 「可能懷孕合併腹痛出血」. Fires when the chief-complaint text contains any of: 月經過期又出血、懷孕腹痛出血 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_pregnancy_abdominal_bleeding` — Structured (semantic) rule — requires LLM extraction: 「可能懷孕合併腹痛出血」. Conditions: `{"primary_in": ["abdomen"], "all_risks": ["pregnancy_possible"], "all_findings": ["vaginal_bleeding"]}`. Finding definitions: vaginal_bleeding = 非預期的陰道出血。

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d426599-1ff2-ae29-7504-6cc43097ca45
- Synthetic cohort: scenario-v2; age: 24
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-09

- Script file: `experiments/scripts/AP-09.yaml`
- sha256 at packet generation: `029dad1424f84f63d306c78fc48e7191b83a810b2cfe050e912668f55fac5691`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: yes
- Patient profile: male, age 45–65; required conditions: peptic ulcer; excluded: none
- Source: authored-for-this-study (seeded from feasibility/redflag-04)
- Validation status (script field): `pending`
- Author notes: Red flag: perforation/peritonitis-like (sudden severe pain, board-like abdomen, ulcer + NSAID). Raw abdomen rule peritonism (term 肚子硬得像木板). Adapted from seed redflag-04 (which also had syncope); syncope removed so the expected set is a single rule.

### Opening statement (verbatim chief complaint)

> 今天突然肚子很痛，整個肚子硬得像木板，動一下就痛

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約兩小時前突然開始。 |
| 性質 character | 持續的劇痛。 |
| 部位 location | 從上腹開始，現在整個肚子都痛。 |
| 嚴重度 severity | 非常痛，難以忍受。 |
| 加重因子 aggravating | 動一下、咳嗽都更痛。 |
| 緩解因子 relieving | 完全不動稍微好一點。 |
| 伴隨症狀 associated | 整個肚子硬硬的、按下去放開更痛、想吐、冒冷汗。 |
| 否認症狀 negatives | 沒有暈倒、沒有吐血、沒有腹瀉。 |
| 過去病史 past history | 以前有胃潰瘍。過去沒有開過刀。 |
| 用藥 medications | 最近因為膝蓋痛自己吃止痛藥（布洛芬）；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 目前每天抽一包菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 無。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 今天突然肚子很痛，整個肚子硬得像木板，動一下就痛 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 有，目前仍在抽 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：胃潰瘍 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 胃潰瘍 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：布洛芬 需要時使用 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 2小時前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 突然發作 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 劇烈，難以忍受 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 持續痛 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 全腹痛 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 噁心、冒冷汗、腹部僵硬或按壓放開更痛 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `peritonism` — Raw phrase rule, route `abdomen`: 「疑似腹膜刺激徵象」. Fires when the chief-complaint text contains any of: 腹部僵硬、肚子硬得像木板 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_peritoneal_irritation` — Structured (semantic) rule — requires LLM extraction: 「疑似腹膜刺激徵象」. Conditions: `{"primary_in": ["abdomen"], "any_findings": ["peritoneal_irritation"]}`. Finding definitions: peritoneal_irritation = 腹部僵硬或按壓後放開時疼痛明顯加劇。

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'abdomen_hx', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d250af9-784f-2848-4163-285dbb09b6d3
- Synthetic cohort: scenario-v2; age: 61
- Active conditions: peptic ulcer
- Active medications: 布洛芬 需要時使用
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Smokes tobacco daily (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：胃潰瘍 | peptic ulcer | text_difference_requires_review |
| current_meds | 其他：布洛芬 需要時使用 | 布洛芬 需要時使用 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 有，目前仍在抽 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## AP-10

- Script file: `experiments/scripts/AP-10.yaml`
- sha256 at packet generation: `b182526cb7b968c9f243a33b9325ced25604f9cb8982c0fc818d694357b66258`
- Chief complaint / expected route: `abdominal_pain` / `abdomen`
- Red-flag variant: yes
- Patient profile: male, age 70–85; required conditions: abdominal aortic aneurysm; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red-flag scenario WITHOUT a current rule (coverage gap). The expected functional outcome under the current rules is NO safety trigger and a full abdomen questionnaire.

### Opening statement (verbatim chief complaint)

> 突然肚子很痛，一直痛到後背，我之前檢查說有腹主動脈瘤

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一小時前突然開始。 |
| 性質 character | 持續的痛，從肚子痛到後背。 |
| 部位 location | 肚臍附近，延伸到後背。 |
| 嚴重度 severity | 非常痛，難以忍受。 |
| 加重因子 aggravating | 一直都很痛。 |
| 緩解因子 relieving | 沒有任何方法能緩解。 |
| 伴隨症狀 associated | 有點想吐。 |
| 否認症狀 negatives | 沒有昏倒、沒有冒冷汗、沒有發燒、沒有腹瀉。 |
| 過去病史 past history | 有高血壓；兩年前健檢發現腹主動脈瘤，醫師說要追蹤。過去沒有開過刀。 |
| 用藥 medications | Amlodipine 5 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 以前抽菸很多年，十年前戒了。 |
| 血型 blood type | A型。 |
| 其他 other | 家人陪同前來。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 突然肚子很痛，一直痛到後背，我之前檢查說有腹主動脈瘤 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | A型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 過去有抽，但已戒菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Amlodipine 5 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 肚子痛從什麼時候開始？ | 1小時前 |
| 症狀問卷 | `start_type` | 腹痛是突然發作，還是逐漸出現？ | 突然發作 |
| 症狀問卷 | `severity` | 目前腹痛的程度如何？ | 劇烈，難以忍受 |
| 症狀問卷 | `quality` | 肚子痛的性質為何？ | 持續痛、由前痛到背後 |
| 症狀問卷 | `location` | 肚子痛的位置在哪裡？ | 其他：肚臍附近痛到後背 |
| 症狀問卷 | `associated` | 是否有下列合併症狀？ | 噁心 |
| 症狀問卷 | `contact_history` | 家中或同行的人是否也有相同症狀？ | 否 |
| 症狀問卷 | `abdomen_hx` | 過去是否有下列腹部相關病史？ | 腹主動脈瘤 |
| 症狀問卷 | `surgery` | 過去是否接受過下列腹部手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

Suspected symptomatic/ruptured AAA without syncope (sudden severe abdominal pain radiating to the back with known AAA) has no rule. finding_codes abdominal_pain_to_back and abdominal_aortic_aneurysm_history exist but no structured_rule references them, and no abdomen rule uses onset/severity; only syncope (semantic_abdominal_syncope), peritoneal_irritation and pregnancy+bleeding are covered.

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'severity', 'quality', 'location', 'associated', 'contact_history', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d1f2c0b-bd2e-73e8-3313-aeca71f088b5
- Synthetic cohort: scenario-v2; age: 75
- Active conditions: abdominal aortic aneurysm; hypertension
- Active medications: Amlodipine 5 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Ex-smoker (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：高血壓 | abdominal aortic aneurysm、hypertension | text_difference_requires_review |
| current_meds | 其他：Amlodipine 5 mg 每日一次 | Amlodipine 5 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 過去有抽，但已戒菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-01

- Script file: `experiments/scripts/CP-01.yaml`
- sha256 at packet generation: `681423f38f65d334985f7df7558136248af039e30fed055c1ed7abcc3064d23c`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: no
- Patient profile: male, age 55–65; required conditions: hypertension; excluded: none
- Source: authored-for-this-study (seeded from feasibility/chest-01)
- Validation status (script field): `pending`
- Author notes: Musculoskeletal-type chest wall pain (reproducible tenderness, movement-related). Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 左邊胸痛三天，轉身或抬手的時候比較痛，按下去也會痛

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 三天前開始，慢慢出現。 |
| 性質 character | 刺刺的痛。 |
| 部位 location | 左邊胸口，痛點固定不會移動；用手按壓會痛。 |
| 嚴重度 severity | 輕微，可以正常上班。 |
| 加重因子 aggravating | 轉身或抬手時比較痛。 |
| 緩解因子 relieving | 休息時比較好。 |
| 伴隨症狀 associated | 沒有其他症狀。 |
| 否認症狀 negatives | 沒有喘、沒有冒冷汗、沒有暈倒、沒有發燒、沒有咳嗽。 |
| 過去病史 past history | 有高血壓；沒有其他心肺疾病。過去沒有開過刀。 |
| 用藥 medications | Amlodipine 5 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 前幾天有搬家具。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 左邊胸痛三天，轉身或抬手的時候比較痛，按下去也會痛 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Amlodipine 5 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 3天前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 逐漸發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 左邊 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 輕微 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 刺痛 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 轉身或抬手 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 休息 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 以上皆無 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 高血壓 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d30c8d2-ee90-9108-f102-e635914928cf
- Synthetic cohort: scenario-v2; age: 61
- Active conditions: hypertension
- Active medications: Amlodipine 5 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：高血壓 | hypertension | text_difference_requires_review |
| current_meds | 其他：Amlodipine 5 mg 每日一次 | Amlodipine 5 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-02

- Script file: `experiments/scripts/CP-02.yaml`
- sha256 at packet generation: `b0e3eed3dc0dc3b9bb0bc6d938adc0a9f9cccd79280945594243d11b7b29558c`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: no
- Patient profile: female, age 40–55; required conditions: gastroesophageal reflux disease; excluded: none
- Source: authored-for-this-study (seeded from feasibility/chest-02)
- Validation status (script field): `pending`
- Author notes: Reflux-type presentation. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 吃完飯後胸口痛，有灼熱感，躺下會更明顯

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一週前開始，慢慢出現。 |
| 性質 character | 燒燒的灼熱感。 |
| 部位 location | 胸口正中間，痛點固定；按壓不會痛。 |
| 嚴重度 severity | 輕微。 |
| 加重因子 aggravating | 吃完飯後、躺下的時候比較明顯。 |
| 緩解因子 relieving | 吃胃藥後會改善。 |
| 伴隨症狀 associated | 常常胃酸逆流、嘴巴酸酸的。 |
| 否認症狀 negatives | 沒有喘、沒有冒冷汗、沒有暈倒、沒有發燒。 |
| 過去病史 past history | 有胃食道逆流；沒有心肺或腦血管疾病。過去沒有開過刀。 |
| 用藥 medications | Esomeprazole 40 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | A型。 |
| 其他 other | 最近常吃宵夜。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 吃完飯後胸口痛，有灼熱感，躺下會更明顯 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | A型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：胃食道逆流 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 胃食道逆流 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Esomeprazole 40 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 1週前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 逐漸發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 正中間 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 輕微 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 灼熱感 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 進食或飯後、其他：躺下時更明顯 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 用藥 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 胃酸逆流或反酸 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'cardio', 'surgery']

### Matched patient

- fhir_patient_id: syn-6d2ae9e6-336f-dca8-5618-f190810692d9
- Synthetic cohort: scenario-v2; age: 49
- Active conditions: gastroesophageal reflux disease
- Active medications: Esomeprazole 40 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：胃食道逆流 | gastroesophageal reflux disease | text_difference_requires_review |
| current_meds | 其他：Esomeprazole 40 mg 每日一次 | Esomeprazole 40 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-03

- Script file: `experiments/scripts/CP-03.yaml`
- sha256 at packet generation: `354ff272e45c6f5a3a7b53eb2220f4b036199dcafe255b746bfaf4b57fe0edf5`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: no
- Patient profile: male, age 60–75; required conditions: hyperlipidemia, type 2 diabetes mellitus; excluded: none
- Source: authored-for-this-study (seeded from feasibility/chest-03)
- Validation status (script field): `pending`
- Author notes: Stable exertional pattern. Author-labelled non-red-flag at the chief-complaint turn (no current rule targets exertional chest pressure that resolves with rest); reviewers should confirm this classification.

### Opening statement (verbatim chief complaint)

> 最近一個月爬樓梯時會胸悶，休息幾分鐘就會好

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一個月前開始，慢慢出現。 |
| 性質 character | 像有重物壓在胸口的悶感。 |
| 部位 location | 胸口正中間，痛點固定；按壓不會痛。 |
| 嚴重度 severity | 中等，要停下來休息。 |
| 加重因子 aggravating | 爬樓梯、快走等耗費體力的活動時出現。 |
| 緩解因子 relieving | 休息幾分鐘就會好。 |
| 伴隨症狀 associated | 沒有其他症狀。 |
| 否認症狀 negatives | 休息時不會悶；沒有冒冷汗、沒有暈倒、沒有喘不過氣。 |
| 過去病史 past history | 有高血脂與糖尿病；沒有已知心臟病或中風。過去沒有開過刀。 |
| 用藥 medications | Atorvastatin 20 mg 每天一次、Metformin 500 mg 每天兩次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 以前有抽菸，十年前戒掉了。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 今天沒有發作，是來看門診。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 最近一個月爬樓梯時會胸悶，休息幾分鐘就會好 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 過去有抽，但已戒菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 糖尿病、高血脂 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Atorvastatin 20 mg 每日一次、Metformin 500 mg 每日兩次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 1個月前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 逐漸發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 正中間 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 中等 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 感覺有重物壓迫 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 耗費體力的活動 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 休息 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 以上皆無 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'cardio', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c51b1a9-27b5-cac7-9d38-d8494062ad6e
- Synthetic cohort: scenario-v2; age: 73
- Active conditions: hyperlipidemia; type 2 diabetes mellitus
- Active medications: Atorvastatin 20 mg 每日一次; Metformin 500 mg 每日兩次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Ex-smoker (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 糖尿病、高血脂 | hyperlipidemia、type 2 diabetes mellitus | text_difference_requires_review |
| current_meds | 其他：Atorvastatin 20 mg 每日一次、Metformin 500 mg 每日兩次 | Atorvastatin 20 mg 每日一次、Metformin 500 mg 每日兩次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 過去有抽，但已戒菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-04

- Script file: `experiments/scripts/CP-04.yaml`
- sha256 at packet generation: `5609b8e2dd53098194e45a968d435d73b79f8d8901ac5758db0b694e25292e57`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: no
- Patient profile: female, age 25–35; required conditions: asthma; excluded: none
- Source: authored-for-this-study (seeded from feasibility/chest-04)
- Validation status (script field): `pending`
- Author notes: Pleuritic pain after a respiratory infection. Non-red-flag control. past_meds answered 以上皆無 (inhaled budesonide is a steroid; reviewers may prefer 類固醇).

### Opening statement (verbatim chief complaint)

> 感冒咳嗽一週，深呼吸和咳嗽時右邊胸痛

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 感冒咳嗽大約一週，胸痛也是一週前慢慢出現。 |
| 性質 character | 刺痛。 |
| 部位 location | 右邊胸口，痛點固定；按壓不會痛。 |
| 嚴重度 severity | 輕微。 |
| 加重因子 aggravating | 深呼吸和咳嗽時比較痛。 |
| 緩解因子 relieving | 休息時比較好。 |
| 伴隨症狀 associated | 咳嗽有白色的痰。 |
| 否認症狀 negatives | 沒有發燒、沒有咳血、沒有喘不過氣、沒有冒冷汗、沒有暈倒。 |
| 過去病史 past history | 有氣喘。過去沒有開過刀。 |
| 用藥 medications | Budesonide/formoterol 吸入劑，需要時使用；以前沒有用過抗組織胺、腎上腺素，也沒有用過口服或針劑類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | O型。 |
| 其他 other | 家人最近也有感冒。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 感冒咳嗽一週，深呼吸和咳嗽時右邊胸痛 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | O型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：氣喘 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 氣喘 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Budesonide/formoterol 吸入劑 需要時使用 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 1週前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 逐漸發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 右邊 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 輕微 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 刺痛 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 深呼吸 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 休息 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 咳嗽有痰 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 氣喘 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c4bd2bc-6c95-1667-a7f9-b44602a47871
- Synthetic cohort: scenario-v2; age: 28
- Active conditions: asthma
- Active medications: Budesonide/formoterol 吸入劑 需要時使用
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：氣喘 | asthma | text_difference_requires_review |
| current_meds | 其他：Budesonide/formoterol 吸入劑 需要時使用 | Budesonide/formoterol 吸入劑 需要時使用 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-05

- Script file: `experiments/scripts/CP-05.yaml`
- sha256 at packet generation: `1acd0a6a8641ebeab0894c66a626cfdb85686a62faddc3936dc5881bdafce191`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: no
- Patient profile: male, age 30–45; required conditions: none; excluded: none
- Source: authored-for-this-study (seeded from feasibility/chest-05)
- Validation status (script field): `pending`
- Author notes: Atypical stress-related chest pain. Seed opening (左胸口刺刺的) had no routing keyword; rephrased to contain 胸口刺痛 so the keyword router is exercised.

### Opening statement (verbatim chief complaint)

> 這一週左邊胸口刺痛，壓力大的時候比較明顯

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一週前，慢慢出現。 |
| 性質 character | 刺刺的。 |
| 部位 location | 左邊胸口，痛點固定；按壓不會痛。 |
| 嚴重度 severity | 輕微。 |
| 加重因子 aggravating | 工作壓力大的時候比較明顯。 |
| 緩解因子 relieving | 坐下來休息、放鬆時比較好。 |
| 伴隨症狀 associated | 沒有其他症狀。 |
| 否認症狀 negatives | 沒有喘、沒有冒冷汗、沒有暈倒、沒有心悸。 |
| 過去病史 past history | 沒有慢性病，沒有心肺疾病。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 對盤尼西林（Penicillin）過敏，會起疹子。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | B型。 |
| 其他 other | 最近常加班。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 這一週左邊胸口刺痛，壓力大的時候比較明顯 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | B型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 其他：Penicillin（盤尼西林） |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 1週前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 逐漸發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 左邊 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 輕微 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 刺痛 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 感到有壓力的時候 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 坐姿 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 以上皆無 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'cardio', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c5d6f81-9df7-3387-de63-4ad29d20fb34
- Synthetic cohort: scenario-v2; age: 34
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: Penicillin（盤尼西林）
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 其他：Penicillin（盤尼西林） | Penicillin（盤尼西林） | text_difference_requires_review |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-06

- Script file: `experiments/scripts/CP-06.yaml`
- sha256 at packet generation: `bc53832a72890da1296f2e0e70ba091e347acf7931da7b2ec9f3dfbcdb1a12d5`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: no
- Patient profile: female, age 35–50; required conditions: none; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: New script. Stress-associated chest tightness with palpitations. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 這兩個禮拜常常胸悶，心跳很快，通常是在工作很緊張的時候

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約兩週前開始，一陣一陣的。 |
| 性質 character | 悶悶緊緊的。 |
| 部位 location | 胸口正中間，痛點固定；按壓不會痛。 |
| 嚴重度 severity | 輕微。 |
| 加重因子 aggravating | 工作很緊張、有壓力的時候。 |
| 緩解因子 relieving | 休息、深呼吸放鬆後會好。 |
| 伴隨症狀 associated | 心跳很快、怦怦跳。 |
| 否認症狀 negatives | 沒有暈倒、沒有冒冷汗、沒有喘不過氣、沒有發燒。 |
| 過去病史 past history | 沒有慢性病，沒有心肺疾病。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 最近睡不好，咖啡喝得比較多。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 這兩個禮拜常常胸悶，心跳很快，通常是在工作很緊張的時候 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 2週前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 逐漸發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 正中間 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 輕微 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 其他：悶悶緊緊的 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 感到有壓力的時候 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 休息 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 感到心跳加速或心跳不規則 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'cardio', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c579094-e2d6-7f27-4b47-da2622fd65d6
- Synthetic cohort: scenario-v2; age: 41
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-07

- Script file: `experiments/scripts/CP-07.yaml`
- sha256 at packet generation: `95fa050073ac3f94ae3550c4cbe32ef43f8e9deaa3d9af8bd374cb05faf9d39d`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: yes
- Patient profile: male, age 55–70; required conditions: hypertension, type 2 diabetes mellitus; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red flag: ACS-like (exertional pressure radiating to arm + diaphoresis). Raw chest rule chest_diaphoresis (term 冒冷汗) fires on the chief turn; raw hits short-circuit semantic extraction.

### Opening statement (verbatim chief complaint)

> 半小時前爬樓梯時突然胸口很痛，像被大石頭壓住，痛到左手臂，還一直冒冷汗

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約三十分鐘前，爬樓梯時突然開始。 |
| 性質 character | 像被大石頭壓住的壓迫感。 |
| 部位 location | 胸口正中間，痛到左手臂；按壓不會痛。 |
| 嚴重度 severity | 非常痛，難以忍受。 |
| 加重因子 aggravating | 爬樓梯時開始，走動更痛。 |
| 緩解因子 relieving | 坐下休息後也沒有改善。 |
| 伴隨症狀 associated | 一直冒冷汗、有點喘、想吐。 |
| 否認症狀 negatives | 沒有暈倒、沒有發燒、沒有咳嗽。 |
| 過去病史 past history | 有高血壓和糖尿病；沒有已知的心臟病。過去沒有開過刀。 |
| 用藥 medications | Metformin 500 mg 每天兩次、Amlodipine 5 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 目前每天抽一包菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 無。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 半小時前爬樓梯時突然胸口很痛，像被大石頭壓住，痛到左手臂，還一直冒冷汗 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 有，目前仍在抽 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 糖尿病、其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Metformin 500 mg 每日兩次、Amlodipine 5 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 30分鐘前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 突然發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 正中間 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 嚴重到難以忍受 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 感覺有重物壓迫 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 耗費體力的活動 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 其他：休息後也沒有改善 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 感到呼吸急促、冒冷汗、感到噁心或已經嘔吐 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 高血壓 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `chest_diaphoresis` — Raw phrase rule, route `chest`: 「胸部不適合併冒冷汗」. Fires when the chief-complaint text contains any of: 冒冷汗 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_chest_diaphoresis` — Structured (semantic) rule — requires LLM extraction: 「胸部不適合併冒冷汗」. Conditions: `{"primary_in": ["chest"], "any_findings": ["diaphoresis"]}`. Finding definitions: diaphoresis = 明確出現大量冷汗。

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c3a35f5-3b32-f947-9d14-fffcd9b003e8
- Synthetic cohort: scenario-v2; age: 60
- Active conditions: hypertension; type 2 diabetes mellitus
- Active medications: Amlodipine 5 mg 每日一次; Metformin 500 mg 每日兩次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Smokes tobacco daily (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 糖尿病、其他：高血壓 | hypertension、type 2 diabetes mellitus | text_difference_requires_review |
| current_meds | 其他：Metformin 500 mg 每日兩次、Amlodipine 5 mg 每日一次 | Metformin 500 mg 每日兩次、Amlodipine 5 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 有，目前仍在抽 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-08

- Script file: `experiments/scripts/CP-08.yaml`
- sha256 at packet generation: `75d1c793ab15c5341d408c11176c7bc8336a74272137e0bf3f46d22fd8d0032e`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: yes
- Patient profile: male, age 60–75; required conditions: hypertension; excluded: none
- Source: authored-for-this-study (seeded from feasibility/redflag-01)
- Validation status (script field): `pending`
- Author notes: Red flag: aortic-dissection-like (sudden tearing pain radiating to back). Opening contains the raw term 胸痛延伸到背部 (tearing_chest_pain). Seed redflag-01 also mentioned 冒冷汗; removed so the expected trigger set is a single rule.

### Opening statement (verbatim chief complaint)

> 剛剛突然胸痛，像被撕開一樣，胸痛延伸到背部

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約二十分鐘前突然開始。 |
| 性質 character | 像被撕開、撕裂一樣。 |
| 部位 location | 胸口正中間，一路痛到背部；按壓不會痛。 |
| 嚴重度 severity | 非常痛，難以忍受。 |
| 加重因子 aggravating | 一直都很痛，沒有特別變化。 |
| 緩解因子 relieving | 沒有任何方法能緩解。 |
| 伴隨症狀 associated | 有點頭暈。 |
| 否認症狀 negatives | 沒有暈倒、沒有發燒、沒有咳嗽。 |
| 過去病史 past history | 有高血壓，平常血壓控制不太好。過去沒有開過刀。 |
| 用藥 medications | Amlodipine 5 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 以前有抽菸，五年前戒了。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 無。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 剛剛突然胸痛，像被撕開一樣，胸痛延伸到背部 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 過去有抽，但已戒菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Amlodipine 5 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 20分鐘前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 突然發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 正中間 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 嚴重到難以忍受 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 撕裂感 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 其他：一直都很痛 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 其他：沒有辦法緩解 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 感到頭暈 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 高血壓 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `tearing_chest_pain` — Raw phrase rule, route `chest`: 「撕裂樣胸背痛」. Fires when the chief-complaint text contains any of: 撕裂樣胸痛、胸痛延伸到背部 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_chest_tearing_pain` — Structured (semantic) rule — requires LLM extraction: 「撕裂樣胸背痛」. Conditions: `{"primary_in": ["chest"], "any_findings": ["tearing_pain"]}`. Finding definitions: tearing_pain = 明確描述撕裂樣疼痛。

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c345707-8012-44e7-1bfb-6a646acc5ae0
- Synthetic cohort: scenario-v2; age: 62
- Active conditions: hypertension
- Active medications: Amlodipine 5 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Ex-smoker (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：高血壓 | hypertension | text_difference_requires_review |
| current_meds | 其他：Amlodipine 5 mg 每日一次 | Amlodipine 5 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 過去有抽，但已戒菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-09

- Script file: `experiments/scripts/CP-09.yaml`
- sha256 at packet generation: `f9747f81d5a86ce95438cacaf94ea69a5f40ef2f648e235f4667a56f37be660a`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: yes
- Patient profile: female, age 30–45; required conditions: none; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red-flag scenario WITHOUT a current rule (coverage gap). The expected functional outcome under the current rules is NO safety trigger and a full chest questionnaire. acceptable lists semantic_severe_breathing in case the extractor grades the dyspnoea as severe.

### Opening statement (verbatim chief complaint)

> 昨天坐了十幾個小時飛機回來，今天右邊胸痛，吸氣會更痛，有點喘，心跳很快，右小腿也腫腫的

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 今天早上起床後突然開始，大約六小時前。 |
| 性質 character | 刺痛。 |
| 部位 location | 右邊胸口，痛點固定；按壓不會痛。 |
| 嚴重度 severity | 中等。 |
| 加重因子 aggravating | 深呼吸、吸氣時比較痛。 |
| 緩解因子 relieving | 目前沒有找到能緩解的方式。 |
| 伴隨症狀 associated | 有點喘、心跳很快、右小腿腫腫痛痛的。 |
| 否認症狀 negatives | 沒有暈倒、沒有冒冷汗、沒有咳血、沒有發燒。 |
| 過去病史 past history | 沒有慢性病，沒有心肺疾病。過去沒有開過刀。 |
| 用藥 medications | 每天吃口服避孕藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 昨天搭了十幾個小時的長途飛機。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 昨天坐了十幾個小時飛機回來，今天右邊胸痛，吸氣會更痛，有點喘，心跳很快，右小腿也腫腫的 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：口服避孕藥 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 6小時前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 突然發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 右邊 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 中等 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 刺痛 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 深呼吸 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 其他：目前沒有找到能緩解的方式 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 感到呼吸急促、感到心跳加速或心跳不規則、其他：右小腿腫痛 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- `semantic_severe_breathing` — Structured (semantic) rule — requires LLM extraction: 「嚴重呼吸困難」. Conditions: `{"any_findings": ["severe_breathing"]}`. Finding definitions: severe_breathing = 嚴重呼吸困難或無法正常呼吸。

### Coverage gap

Suspected pulmonary embolism (pleuritic chest pain + dyspnoea + tachycardia + unilateral leg swelling after long-haul travel) has no rule. finding_codes pleuritic_pain, dyspnea and tachycardia exist but no structured_rule references them; severe_breathing fires only for raw terms 無法呼吸/喘不過氣/嘴唇發紫 or an LLM 'severe_breathing' finding, which 有點喘 should not produce.

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'cardio', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c45f3ce-b174-6207-f780-6b2f9a57f8da
- Synthetic cohort: scenario-v2; age: 43
- Active conditions: no records; not an assertion of clinical absence
- Active medications: 口服避孕藥 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 其他：口服避孕藥 每日一次 | 口服避孕藥 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## CP-10

- Script file: `experiments/scripts/CP-10.yaml`
- sha256 at packet generation: `faaee81c81a11ce322f5f5c024df21622123ed13c6d40dce0bec851890d56112`
- Chief complaint / expected route: `chest_pain` / `chest`
- Red-flag variant: yes
- Patient profile: male, age 65–80; required conditions: hypertension, hyperlipidemia; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red flag: chest discomfort with syncope. Raw chest rule chest_syncope (term 暈倒).

### Opening statement (verbatim chief complaint)

> 今天早上胸悶，在公園散步時突然暈倒，醒來還是悶悶的

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 今天早上大約兩小時前開始胸悶，散步時突然暈倒。 |
| 性質 character | 悶悶的、像有東西壓著。 |
| 部位 location | 胸口正中間，痛點固定；按壓不會痛。 |
| 嚴重度 severity | 中等。 |
| 加重因子 aggravating | 走路時比較明顯。 |
| 緩解因子 relieving | 休息後稍微好一點。 |
| 伴隨症狀 associated | 暈倒過一次，醒來後還有點頭暈。 |
| 否認症狀 negatives | 沒有冒冷汗、沒有發燒、沒有咳嗽、沒有撞到頭。 |
| 過去病史 past history | 有高血壓和高血脂。過去沒有開過刀。 |
| 用藥 medications | Amlodipine 5 mg 每天一次、Atorvastatin 20 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | O型。 |
| 其他 other | 暈倒時旁邊有路人扶起來。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 今天早上胸悶，在公園散步時突然暈倒，醒來還是悶悶的 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | O型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 高血脂、其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Amlodipine 5 mg 每日一次、Atorvastatin 20 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 胸痛從什麼時候開始？ | 2小時前 |
| 症狀問卷 | `start_type` | 胸痛是突然發作，還是逐漸發作？ | 突然發作 |
| 症狀問卷 | `location` | 胸痛的位置在哪裡？ | 正中間 |
| 症狀問卷 | `fixed` | 胸痛的位置是否會移動？ | 痛點固定 |
| 症狀問卷 | `tender` | 用手按壓疼痛部位時，是否會有壓痛感？ | 沒有 |
| 症狀問卷 | `severity` | 目前胸痛的嚴重程度如何？ | 中等 |
| 症狀問卷 | `quality` | 您會如何描述這種疼痛？ | 感覺有重物壓迫 |
| 症狀問卷 | `aggravate` | 哪些情況會使疼痛加重？ | 耗費體力的活動 |
| 症狀問卷 | `relieve` | 哪些情況能緩解疼痛？ | 休息 |
| 症狀問卷 | `associated` | 是否同時出現以下症狀？ | 有昏厥或暈倒、感到頭暈 |
| 症狀問卷 | `cardio` | 過去是否有下列心肺或腦血管疾病？ | 高血壓 |
| 症狀問卷 | `surgery` | 過去是否接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `chest_syncope` — Raw phrase rule, route `chest`: 「胸部不適合併昏厥」. Fires when the chief-complaint text contains any of: 昏厥、暈倒 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_chest_syncope` — Structured (semantic) rule — requires LLM extraction: 「胸部不適合併昏厥」. Conditions: `{"primary_in": ["chest"], "any_findings": ["syncope"]}`. Finding definitions: syncope = 短暫失去意識或昏倒。
- `semantic_altered_consciousness` — Structured (semantic) rule — requires LLM extraction: 「意識狀態異常」. Conditions: `{"any_findings": ["altered_consciousness", "syncope"]}`. Finding definitions: altered_consciousness = 意識改變、反應異常或無法正常喚醒。; syncope = 短暫失去意識或昏倒。

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'fixed', 'tender', 'severity', 'quality', 'aggravate', 'relieve', 'associated', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c4014e1-f653-ada7-b030-d043e11b8844
- Synthetic cohort: scenario-v2; age: 74
- Active conditions: hyperlipidemia; hypertension
- Active medications: Amlodipine 5 mg 每日一次; Atorvastatin 20 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 高血脂、其他：高血壓 | hypertension、hyperlipidemia | text_difference_requires_review |
| current_meds | 其他：Amlodipine 5 mg 每日一次、Atorvastatin 20 mg 每日一次 | Amlodipine 5 mg 每日一次、Atorvastatin 20 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-01

- Script file: `experiments/scripts/HA-01.yaml`
- sha256 at packet generation: `ded73b7103f68b3bba5d163f75ba24a3d661997851b8580ee7b96fa03fecbe18`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: no
- Patient profile: female, age 30–40; required conditions: none; excluded: none
- Source: authored-for-this-study (seeded from feasibility/headache-01)
- Validation status (script field): `pending`
- Author notes: Tension-type presentation. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 頭痛兩天，兩邊太陽穴緊緊的，工作壓力大

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 兩天前開始，慢慢加重。 |
| 性質 character | 像被緊緊束住、緊緊的。 |
| 部位 location | 兩邊太陽穴，兩側都痛。 |
| 嚴重度 severity | 中等，還可以上班。 |
| 加重因子 aggravating | 工作一整天、身體活動後比較明顯。 |
| 緩解因子 relieving | 休息後會好一些。 |
| 伴隨症狀 associated | 沒有其他症狀。 |
| 否認症狀 negatives | 不是這輩子最痛的頭痛；沒有發燒、沒有嘔吐、沒有視力模糊、沒有手腳無力。 |
| 過去病史 past history | 沒有慢性病，沒有神經方面的病史。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 最近工作壓力大、睡眠不足。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 頭痛兩天，兩邊太陽穴緊緊的，工作壓力大 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 2天前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 兩側都痛 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 不是，跟以前差不多或較輕 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 像被緊緊束住 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 身體活動 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 休息 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 以上皆無 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c22ba41-4eb0-27c7-e860-d9b7ad7a162e
- Synthetic cohort: scenario-v2; age: 39
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-02

- Script file: `experiments/scripts/HA-02.yaml`
- sha256 at packet generation: `73fdf57f1dbd3c36f758278a0669b00d638cfac972389a0062148a3478c5c9b3`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: no
- Patient profile: female, age 35–45; required conditions: migraine; excluded: none
- Source: authored-for-this-study (seeded from feasibility/headache-02)
- Validation status (script field): `pending`
- Author notes: Known migraine, typical attack. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 又開始偏頭痛，右邊一跳一跳的，怕光想吐

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 昨天開始，慢慢加重。 |
| 性質 character | 像脈搏一樣一跳一跳的。 |
| 部位 location | 右邊單側。 |
| 嚴重度 severity | 中等，跟以前偏頭痛發作差不多。 |
| 加重因子 aggravating | 看到亮光會更痛。 |
| 緩解因子 relieving | 待在黑暗安靜的地方會好一點。 |
| 伴隨症狀 associated | 想吐、怕光。 |
| 否認症狀 negatives | 不是這輩子最痛的頭痛；沒有發燒、沒有手腳無力、沒有講話不清楚、沒有視力模糊。 |
| 過去病史 past history | 多年偏頭痛病史。過去沒有開過刀。 |
| 用藥 medications | Sumatriptan 50 mg 需要時使用；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | A型。 |
| 其他 other | 月經快來了。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 又開始偏頭痛，右邊一跳一跳的，怕光想吐 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | A型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：偏頭痛 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 偏頭痛 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Sumatriptan 50 mg 需要時使用 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 1天前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 單側 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 不是，跟以前差不多或較輕 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 像脈搏一樣的跳痛 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 光線刺激 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 待在黑暗安靜的地方 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 噁心或嘔吐、畏光 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 偏頭痛病史 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c1cdb53-938f-7366-4f58-59308b4c4573
- Synthetic cohort: scenario-v2; age: 42
- Active conditions: migraine
- Active medications: Sumatriptan 50 mg 需要時使用
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：偏頭痛 | migraine | text_difference_requires_review |
| current_meds | 其他：Sumatriptan 50 mg 需要時使用 | Sumatriptan 50 mg 需要時使用 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-03

- Script file: `experiments/scripts/HA-03.yaml`
- sha256 at packet generation: `1212153bcf543536709ce0413103fe7ba167991a541059ef117271c75fc625bd`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: no
- Patient profile: male, age 50–60; required conditions: hypertension; excluded: none
- Source: authored-for-this-study (seeded from feasibility/headache-03)
- Validation status (script field): `pending`
- Author notes: Sinus-type presentation. Non-red-flag control. associated uses a single free-text 其他 entry (the validator permits at most one 其他： segment).

### Opening statement (verbatim chief complaint)

> 感冒後前額頭痛，鼻塞，彎腰時更痛

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 感冒後大約一週，慢慢加重。 |
| 性質 character | 悶悶脹脹的。 |
| 部位 location | 前額。 |
| 嚴重度 severity | 輕微到中等。 |
| 加重因子 aggravating | 彎腰、低頭時更痛。 |
| 緩解因子 relieving | 休息時比較好。 |
| 伴隨症狀 associated | 鼻塞、有黃鼻涕。 |
| 否認症狀 negatives | 不是這輩子最痛的頭痛；沒有發燒、沒有脖子僵硬、沒有手腳無力。 |
| 過去病史 past history | 有高血壓。過去沒有開過刀。 |
| 用藥 medications | Losartan 50 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 無。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 感冒後前額頭痛，鼻塞，彎腰時更痛 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Losartan 50 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 1週前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 前額 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 不是，跟以前差不多或較輕 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 悶脹痛 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 彎腰低頭 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 休息 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 其他：鼻塞、黃鼻涕 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c2e781a-c4f1-9087-b98a-a8e29108ad54
- Synthetic cohort: scenario-v2; age: 58
- Active conditions: hypertension
- Active medications: Losartan 50 mg 每日一次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：高血壓 | hypertension | text_difference_requires_review |
| current_meds | 其他：Losartan 50 mg 每日一次 | Losartan 50 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-04

- Script file: `experiments/scripts/HA-04.yaml`
- sha256 at packet generation: `879453a502980abd5ae674270c0e6277d2bfbd93be286d24a2db55c7dde3e663`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: no
- Patient profile: female, age 55–65; required conditions: hypothyroidism; excluded: none
- Source: authored-for-this-study (seeded from feasibility/headache-04)
- Validation status (script field): `pending`
- Author notes: Medication-overuse pattern. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 這個月幾乎每天頭痛，止痛藥越吃越多

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一個月前開始，慢慢變成幾乎每天。 |
| 性質 character | 像被緊緊束住。 |
| 部位 location | 整個頭。 |
| 嚴重度 severity | 中等。 |
| 加重因子 aggravating | 活動多的時候比較明顯。 |
| 緩解因子 relieving | 吃止痛藥會暫時好，但越吃越多。 |
| 伴隨症狀 associated | 沒有其他症狀。 |
| 否認症狀 negatives | 不是這輩子最痛的頭痛；沒有發燒、沒有嘔吐、沒有視力模糊、沒有手腳無力。 |
| 過去病史 past history | 有甲狀腺功能低下。過去沒有開過刀。 |
| 用藥 medications | Levothyroxine 50 mcg 每天一次；另外自己買普拿疼，最近幾乎每天吃。以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 無。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 這個月幾乎每天頭痛，止痛藥越吃越多 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：甲狀腺功能低下 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 甲狀腺功能低下 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Levothyroxine 50 mcg 每日一次、普拿疼 幾乎每日 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 1個月前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 整個頭 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 不是，跟以前差不多或較輕 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 像被緊緊束住 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 身體活動 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 使用止痛藥 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 以上皆無 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c28992e-09d0-dc27-d7f3-4c35c6199bf6
- Synthetic cohort: scenario-v2; age: 57
- Active conditions: hypothyroidism
- Active medications: Levothyroxine 50 mcg 每日一次; 普拿疼 幾乎每日
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：甲狀腺功能低下 | hypothyroidism | text_difference_requires_review |
| current_meds | 其他：Levothyroxine 50 mcg 每日一次、普拿疼 幾乎每日 | Levothyroxine 50 mcg 每日一次、普拿疼 幾乎每日 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-05

- Script file: `experiments/scripts/HA-05.yaml`
- sha256 at packet generation: `5b4e27f291bee19641ebac0fbdc5ca998bfdc6caffd10d9503033f444a3139ab`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: no
- Patient profile: male, age 40–50; required conditions: none; excluded: none
- Source: authored-for-this-study (seeded from feasibility/headache-05)
- Validation status (script field): `pending`
- Author notes: Cervicogenic/tension-type pattern. Seed opening had no routing keyword; rephrased to start with 頭痛 so the keyword router is exercised.

### Opening statement (verbatim chief complaint)

> 頭痛好幾天了，後腦勺到脖子一直緊緊的，低頭用電腦更明顯

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一週前，慢慢加重。 |
| 性質 character | 緊緊的、像被束住。 |
| 部位 location | 後腦勺延伸到脖子。 |
| 嚴重度 severity | 輕微到中等。 |
| 加重因子 aggravating | 低頭用電腦時更明顯。 |
| 緩解因子 relieving | 按摩脖子會比較舒服。 |
| 伴隨症狀 associated | 沒有其他症狀。 |
| 否認症狀 negatives | 不是這輩子最痛的頭痛；沒有發燒、脖子可以正常彎、沒有手腳無力。 |
| 過去病史 past history | 沒有慢性病。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 每天用電腦超過十小時。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 頭痛好幾天了，後腦勺到脖子一直緊緊的，低頭用電腦更明顯 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 1週前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 後腦勺及頸部 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 不是，跟以前差不多或較輕 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 像被緊緊束住 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 彎腰低頭 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 按摩頭頸部 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 以上皆無 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c0b3e8e-622d-5646-d5d6-7b6a8d07fb80
- Synthetic cohort: scenario-v2; age: 44
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-06

- Script file: `experiments/scripts/HA-06.yaml`
- sha256 at packet generation: `79f8396df78319dbd94d7f940e050409fd9b23dbe5ce6946a0c464aaa123c614`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: no
- Patient profile: male, age 55–70; required conditions: hypertension; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: New script. Headache with missed antihypertensive doses, no neurological symptoms. Non-red-flag control.

### Opening statement (verbatim chief complaint)

> 這兩天早上起床就後腦痛，脹脹的，血壓藥前幾天忘了吃

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 兩天前開始，慢慢出現。 |
| 性質 character | 悶悶脹脹的。 |
| 部位 location | 後腦勺到脖子。 |
| 嚴重度 severity | 輕微到中等。 |
| 加重因子 aggravating | 早上剛起床時比較明顯。 |
| 緩解因子 relieving | 休息後會好一點。 |
| 伴隨症狀 associated | 沒有其他症狀。 |
| 否認症狀 negatives | 不是這輩子最痛的頭痛；沒有嘔吐、沒有視力模糊、沒有手腳無力、沒有講話不清楚。 |
| 過去病史 past history | 有高血壓。過去沒有開過刀。 |
| 用藥 medications | Amlodipine 5 mg 每天一次，最近三天忘了吃；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 以前有抽菸，已經戒了。 |
| 血型 blood type | B型。 |
| 其他 other | 家裡量血壓比平常高。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 這兩天早上起床就後腦痛，脹脹的，血壓藥前幾天忘了吃 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | B型 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 過去有抽，但已戒菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Amlodipine 5 mg 每日一次（最近三天漏服） |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 2天前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 後腦勺及頸部 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 不是，跟以前差不多或較輕 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 悶脹痛 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 其他：早上起床時比較明顯 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 休息 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 以上皆無 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- (none)

Acceptable alternatives:

- (none)

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c055fa0-a70c-a1e6-8ebc-5ca77aec2659
- Synthetic cohort: scenario-v2; age: 67
- Active conditions: hypertension
- Active medications: Amlodipine 5 mg 每日一次（最近三天漏服）
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Ex-smoker (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：高血壓 | hypertension | text_difference_requires_review |
| current_meds | 其他：Amlodipine 5 mg 每日一次（最近三天漏服） | Amlodipine 5 mg 每日一次（最近三天漏服） | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 過去有抽，但已戒菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-07

- Script file: `experiments/scripts/HA-07.yaml`
- sha256 at packet generation: `d48658dc6d2feb6651f3fd4480a72eed2da109982a5dd6f9de16cc1289191d0a`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: yes
- Patient profile: female, age 45–60; required conditions: none; excluded: none
- Source: authored-for-this-study (seeded from feasibility/redflag-02)
- Validation status (script field): `pending`
- Author notes: Red flag: SAH-like thunderclap headache. Opening contains raw term 此生最嚴重的頭痛 (thunderclap_headache). Seed redflag-02 phrasing (這輩子最嚴重的頭痛) would NOT match any raw term and would rely on semantic_sudden_severe_headache.

### Opening statement (verbatim chief complaint)

> 剛剛搬東西時突然頭痛，好像被雷打到，是我此生最嚴重的頭痛，還吐了

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約四十分鐘前搬東西時，幾秒內就痛到最嚴重。 |
| 性質 character | 像爆炸一樣、被雷打到。 |
| 部位 location | 整個頭。 |
| 嚴重度 severity | 這輩子最痛的一次。 |
| 加重因子 aggravating | 動一下就更痛。 |
| 緩解因子 relieving | 躺著休息也沒有用。 |
| 伴隨症狀 associated | 吐了兩次。 |
| 否認症狀 negatives | 沒有發燒、沒有手腳無力、沒有講話不清楚、沒有昏倒。 |
| 過去病史 past history | 沒有慢性病，沒有偏頭痛或腦血管病史。過去沒有開過刀。 |
| 用藥 medications | 目前沒有吃藥；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 無。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 剛剛搬東西時突然頭痛，好像被雷打到，是我此生最嚴重的頭痛，還吐了 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 沒有 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 40分鐘前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 瞬間爆炸性 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 整個頭 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 是，前所未有的劇痛 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 其他：像爆炸一樣 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 身體活動 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 其他：休息也沒有用 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 噁心或嘔吐 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `thunderclap_headache` — Raw phrase rule, route `headache`: 「突發爆炸性頭痛」. Fires when the chief-complaint text contains any of: 雷擊般頭痛、此生最嚴重的頭痛 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_sudden_severe_headache` — Structured (semantic) rule — requires LLM extraction: 「突發劇烈頭痛」. Conditions: `{"primary_in": ["headache"], "onset_in": ["sudden"], "severity_in": ["severe"]}`.

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'current_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c16fc67-d86e-bf06-813a-6149a923a8e4
- Synthetic cohort: scenario-v2; age: 47
- Active conditions: no records; not an assertion of clinical absence
- Active medications: no records; not an assertion of clinical absence
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 沒有 | None | not_prefilled |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-08

- Script file: `experiments/scripts/HA-08.yaml`
- sha256 at packet generation: `6b466d617767b393f7bd8c7ccc19f056319be6647645969215188e4c36e9f25a`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: yes
- Patient profile: male, age 18–30; required conditions: none; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red flag: meningitis-like (fever + neck stiffness). Natural phrasing intentionally does NOT contain the raw term 頸部僵硬合併發燒, so detection depends on LLM extraction (fever + neck_stiffness -> semantic_meningism). Tests the semantic safety path; lint marks it requires_llm.

### Opening statement (verbatim chief complaint)

> 頭痛三天越來越嚴重，發燒到三十九度，脖子很硬，低頭下巴碰不到胸口

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 三天前開始，越來越嚴重。 |
| 性質 character | 整個頭脹痛。 |
| 部位 location | 整個頭，後腦和脖子特別緊。 |
| 嚴重度 severity | 很痛，已經沒辦法上課。 |
| 加重因子 aggravating | 低頭、看到亮光時更痛。 |
| 緩解因子 relieving | 吃退燒止痛藥只能撐一下子。 |
| 伴隨症狀 associated | 發燒到三十九度、脖子很硬、想吐、怕光。 |
| 否認症狀 negatives | 沒有手腳無力、沒有講話不清楚、沒有撞到頭。 |
| 過去病史 past history | 沒有慢性病。過去沒有開過刀。 |
| 用藥 medications | 這兩天自己吃普拿疼；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 住學校宿舍，室友上週也有發燒。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 頭痛三天越來越嚴重，發燒到三十九度，脖子很硬，低頭下巴碰不到胸口 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 以上皆無 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：普拿疼 需要時使用 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 3天前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 整個頭 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 是，前所未有的劇痛 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 悶脹痛 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 彎腰低頭、光線刺激 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 使用止痛藥 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 噁心或嘔吐、畏光、頸部僵硬合併發燒 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `semantic_meningism` — Structured (semantic) rule — requires LLM extraction: 「頭痛合併發燒與頸部僵硬」. Conditions: `{"primary_in": ["headache"], "all_findings": ["fever", "neck_stiffness"]}`. Finding definitions: fever = 患者明確表示發燒。; neck_stiffness = 頸部僵硬或難以前彎。

Acceptable alternatives:

- `meningism` — Raw phrase rule, route `headache`: 「頭痛合併發燒與頸部僵硬」. Fires when the chief-complaint text contains any of: 頸部僵硬合併發燒 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'chronic', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6c111d7b-1d4e-0aa6-68f1-ec17072b90df
- Synthetic cohort: scenario-v2; age: 23
- Active conditions: no records; not an assertion of clinical absence
- Active medications: 普拿疼 需要時使用
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 以上皆無 | None | not_prefilled |
| current_meds | 其他：普拿疼 需要時使用 | 普拿疼 需要時使用 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-09

- Script file: `experiments/scripts/HA-09.yaml`
- sha256 at packet generation: `12f40fc486388155adb641109ecfdc7f10798997222c39433d81a32c05506f83`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: yes
- Patient profile: male, age 65–80; required conditions: hypertension, type 2 diabetes mellitus; excluded: none
- Source: authored-for-this-study (seeded from feasibility/redflag-03)
- Validation status (script field): `pending`
- Author notes: Red flag: headache with focal neurological deficit. Raw headache rule focal_neurologic_deficit (term 講話不清楚). Note the negation look-back (8 chars, includes 沒): phrasing such as 「手腳沒力、講話不清楚」 would suppress the match, so 使不上力 is used.

### Opening statement (verbatim chief complaint)

> 頭痛，右手右腳突然使不上力，講話不清楚

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 大約一小時前突然開始。 |
| 性質 character | 頭悶悶的痛。 |
| 部位 location | 左邊單側。 |
| 嚴重度 severity | 中等，但手腳沒力讓我很害怕。 |
| 加重因子 aggravating | 沒有特別注意到。 |
| 緩解因子 relieving | 沒有特別能緩解的方法。 |
| 伴隨症狀 associated | 右手右腳使不上力、講話不清楚。 |
| 否認症狀 negatives | 沒有發燒、沒有撞到頭、沒有昏倒。 |
| 過去病史 past history | 有高血壓和糖尿病；沒有中風病史。過去沒有開過刀。 |
| 用藥 medications | Metformin 500 mg 每天兩次、Amlodipine 5 mg 每天一次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 以前有抽菸，已經戒了。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 家人陪同前來。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 頭痛，右手右腳突然使不上力，講話不清楚 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 男性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 過去有抽，但已戒菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 糖尿病、其他：高血壓 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 高血壓 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Metformin 500 mg 每日兩次、Amlodipine 5 mg 每日一次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 1小時前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 其他：頭痛慢慢出現，手腳無力是突然的 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 單側 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 不是，跟以前差不多或較輕 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 悶脹痛 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 其他：沒有特別注意到 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 其他：沒有特別能緩解的方法 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 單側肢體無力或麻木、講話不清楚 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 以上皆無 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `focal_neurologic_deficit` — Raw phrase rule, route `headache`: 「疑似局部神經功能異常」. Fires when the chief-complaint text contains any of: 單側肢體無力、講話不清楚、臉歪 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_focal_weakness` — Structured (semantic) rule — requires LLM extraction: 「疑似局部神經功能異常」. Conditions: `{"any_findings": ["focal_weakness"]}`. Finding definitions: focal_weakness = 單側或局部肢體無力。
- `semantic_speech_difficulty` — Structured (semantic) rule — requires LLM extraction: 「疑似局部神經功能異常」. Conditions: `{"any_findings": ["speech_difficulty"]}`. Finding definitions: speech_difficulty = 說話含糊、無法表達或理解語言。

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6cafa076-d9c1-10c7-5ee5-342b8a446749
- Synthetic cohort: scenario-v2; age: 76
- Active conditions: hypertension; type 2 diabetes mellitus
- Active medications: Amlodipine 5 mg 每日一次; Metformin 500 mg 每日兩次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Ex-smoker (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 糖尿病、其他：高血壓 | hypertension、type 2 diabetes mellitus | text_difference_requires_review |
| current_meds | 其他：Metformin 500 mg 每日兩次、Amlodipine 5 mg 每日一次 | Metformin 500 mg 每日兩次、Amlodipine 5 mg 每日一次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 過去有抽，但已戒菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>

## HA-10

- Script file: `experiments/scripts/HA-10.yaml`
- sha256 at packet generation: `241880a1040ded37686f22a55b65c1fe4381ff70d7ee92a36ba7fe4e4b92438f`
- Chief complaint / expected route: `headache` / `headache`
- Red-flag variant: yes
- Patient profile: female, age 60–75; required conditions: atrial fibrillation; excluded: none
- Source: authored-for-this-study
- Validation status (script field): `pending`
- Author notes: Red flag: headache with transient loss of consciousness on an anticoagulant. Universal raw rule altered_consciousness (term 失去意識) fires first.

### Opening statement (verbatim chief complaint)

> 今天早上頭痛得很厲害，在客廳突然失去意識幾分鐘，家人把我叫醒

### Patient facts (only facts the simulated patient may reveal)

| Topic | Fact |
| --- | --- |
| 發作時間 onset | 今天早上大約三小時前開始頭痛，之後在客廳失去意識幾分鐘。 |
| 性質 character | 脹痛。 |
| 部位 location | 整個頭。 |
| 嚴重度 severity | 很痛，難以忍受。 |
| 加重因子 aggravating | 起身走動時更痛。 |
| 緩解因子 relieving | 沒有特別能緩解的方法。 |
| 伴隨症狀 associated | 失去意識幾分鐘，醒來後有點想睡、想吐。 |
| 否認症狀 negatives | 沒有發燒、沒有撞到頭、沒有手腳無力。 |
| 過去病史 past history | 有心律不整（心房顫動）。過去沒有開過刀。 |
| 用藥 medications | Apixaban 5 mg 每天兩次；以前沒有用過抗組織胺、腎上腺素或類固醇。 |
| 過敏 allergies | 沒有已知的藥物或食物過敏。 |
| 抽菸 smoking | 從來沒有抽菸。 |
| 血型 blood type | 不知道自己的血型。 |
| 其他 other | 家人陪同前來。 |

### Expected answers

| Section | Field (linkId) | Question prompt | Expected answer |
| --- | --- | --- | --- |
| 主訴 | `reason` | 請自由描述今天最不舒服的症狀、部位，以及發生的情況。 | 今天早上頭痛得很厲害，在客廳突然失去意識幾分鐘，家人把我叫醒 |
| 基本資料 | `name` | 請輸入您的姓名。 | __FROM_PATIENT__ |
| 基本資料 | `gender` | 請選擇您的生理性別。 | 女性 |
| 基本資料 | `birth_date` | 請選擇您的出生日期，系統會自動計算年齡。 | __FROM_PATIENT__ |
| 基本資料 | `blood_type` | 請選擇您的血型。 | 不清楚 |
| 病史 | `smoke` | 平時是否有抽菸習慣？ | 沒有，從未抽菸 |
| 病史 | `chronic` | 過去是否有下列慢性疾病史？ | 其他：心房顫動 |
| 病史 | `chronic_detail` | 請補充慢性疾病、自體免疫疾病或癌症的病名。 | 心房顫動 |
| 病史 | `past_meds` | 之前是否曾接受過以下藥物治療？ | 以上皆無 |
| 病史 | `current_meds` | 目前是否有正在服用的藥物？ | 其他：Apixaban 5 mg 每日兩次 |
| 病史 | `allergy` | 是否有特殊藥物或食物過敏？ | 沒有 |
| 症狀問卷 | `onset` | 這次頭痛大約從什麼時候開始？ | 3小時前 |
| 症狀問卷 | `start_type` | 頭痛是幾秒內達到最劇烈，還是慢慢加重？ | 逐漸加重 |
| 症狀問卷 | `location` | 頭痛的位置主要在哪裡？ | 整個頭 |
| 症狀問卷 | `worst_ever` | 這是您至今最嚴重的一次頭痛嗎？ | 是，前所未有的劇痛 |
| 症狀問卷 | `quality` | 您會怎麼描述頭痛的感覺？ | 悶脹痛 |
| 症狀問卷 | `aggravate` | 什麼情況下頭痛會比較嚴重？ | 身體活動 |
| 症狀問卷 | `relieve` | 什麼情況下頭痛會比較緩解？ | 其他：沒有特別能緩解的方法 |
| 症狀問卷 | `associated` | 除了頭痛，還有哪些症狀？ | 噁心或嘔吐、意識改變或嗜睡 |
| 症狀問卷 | `risk_flags` | 請問是否有以下情形？ | 目前服用抗凝血藥物 |
| 症狀問卷 | `neuro` | 過去是否有以下神經血管相關疾病？ | 以上皆無 |
| 症狀問卷 | `surgery` | 過去是否曾接受過下列手術？ | 未曾手術 |

`__FROM_PATIENT__` = filled from the matched synthetic FHIR patient.

### Expected safety triggers (engine record order)

- `altered_consciousness` — Raw phrase rule, universal (all routes): 「意識狀態異常」. Fires when the chief-complaint text contains any of: 失去意識、昏迷、叫不醒 (negated if any of 沒有、無、否認、未曾、並無、不是、沒 appears within 8 chars before the term).

Acceptable alternatives:

- `semantic_altered_consciousness` — Structured (semantic) rule — requires LLM extraction: 「意識狀態異常」. Conditions: `{"any_findings": ["altered_consciousness", "syncope"]}`. Finding definitions: altered_consciousness = 意識改變、反應異常或無法正常喚醒。; syncope = 短暫失去意識或昏倒。

### Coverage gap

(none)

### Expected questionnaire path

['reason', 'smoke', 'past_meds', 'allergy', 'onset', 'start_type', 'location', 'worst_ever', 'quality', 'aggravate', 'relieve', 'associated', 'risk_flags', 'neuro', 'surgery']

### Matched patient

- fhir_patient_id: syn-6ca9c18a-1ea0-5c67-ff84-837edf2491ea
- Synthetic cohort: scenario-v2; age: 65
- Active conditions: atrial fibrillation
- Active medications: Apixaban 5 mg 每日兩次
- Allergies: no records; not an assertion of clinical absence
- Smoking observation: Never smoked tobacco (finding)

### Actual prefill versus authored answers (text differences require review)

| Field | Authored answer | Actual prefill | Comparison |
| --- | --- | --- | --- |
| chronic | 其他：心房顫動 | atrial fibrillation | text_difference_requires_review |
| current_meds | 其他：Apixaban 5 mg 每日兩次 | Apixaban 5 mg 每日兩次 | text_difference_requires_review |
| allergy | 沒有 | None | not_prefilled |
| smoke | 沒有，從未抽菸 | None | not_prefilled |

### Reviewer checklist (record decisions in VALIDATION_LOG.md, not here)

- [ ] Clinically plausible scenario
- [ ] Patient facts internally consistent with expected answers
- [ ] Expected route correct
- [ ] Expected safety triggers / coverage gap correct
- [ ] Expected questionnaire path correct (once filled)

<div style="page-break-after: always;"></div>
